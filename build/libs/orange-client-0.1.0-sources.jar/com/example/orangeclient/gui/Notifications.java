package com.example.orangeclient.gui;

import com.example.orangeclient.module.render.Hud;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5250;

/** Powiadomienia "Modul wlaczony / wylaczony" (pozycja z modulu HUD, domyslnie prawy dol ekranu). */
public final class Notifications {
    public static final int H = 18;
    private static final int GAP = 4, MAX = 5;
    private static final long IN_MS = 220L, HOLD_MS = 1700L, OUT_MS = 280L;
    private static final int GREEN = 0xFF55E07A, RED = 0xFFFF5F5F;

    private static final class_2960 FONT_ID = class_2960.method_60655("orangeclient", "ui");
    private static final class_2960 FONT_FILE = class_2960.method_60655("orangeclient", "font/ui.ttf");
    private static Boolean customFont;

    private static final class Notif {
        String name;
        boolean on;
        long born;
        float y = -1f;
    }

    private static final List<Notif> LIST = new ArrayList<>();
    private static long lastFrame;

    private Notifications() { }

    public static void push(String name, boolean on) {
        LIST.removeIf(n -> n.name.equals(name));      // ten sam modul: nowe powiadomienie zastepuje stare
        Notif n = new Notif();
        n.name = name;
        n.on = on;
        n.born = class_156.method_658();
        LIST.add(n);
        while (LIST.size() > MAX) LIST.remove(0);
    }

    private static class_5250 font(class_2561 t) {
        if (customFont == null) {
            customFont = class_310.method_1551().method_1478().method_14486(FONT_FILE).isPresent();
        }
        class_5250 m = t.method_27661();
        return customFont ? m.method_27694(st -> st.method_27704(FONT_ID)) : m;
    }

    private static class_5250 label(String name, boolean on) {
        int statusCol = on ? GREEN : RED;
        return font(class_2561.method_43470(name))
                .method_10852(font(class_2561.method_43470(on ? "  enabled" : "  disabled")).method_27694(st -> st.method_36139(statusCol & 0xFFFFFF)));
    }

    public static int cardWidth(class_327 tr, String name, boolean on) {
        return 8 + 6 + 6 + tr.method_27525(label(name, on)) + 10;
    }

    /** Rysuje jedna karte powiadomienia w (x, y) o szerokosci w (z cardWidth) - uzywane tez w edytorze HUD. */
    public static void drawCard(class_332 ctx, class_327 tr, int x, int y, int w, String name, boolean on) {
        int statusCol = on ? GREEN : RED;
        ClickGui.roundRect(ctx, x, y, x + w, y + H, 9, 0xAAFF7A00);
        ClickGui.roundRectGradient(ctx, x + 1, y + 1, x + w - 1, y + H - 1, 8, 0xF0241710, 0xF00F0A07, true);
        ClickGui.roundRect(ctx, x + 8, y + 6, x + 14, y + 12, 3, statusCol);
        ctx.method_27535(tr, label(name, on), x + 20, y + 5, 0xFFFFFFFF);
    }

    public static void render(class_332 ctx) {
        if (LIST.isEmpty() || !Hud.notifVisible()) {
            lastFrame = 0;
            return;
        }
        class_310 mc = class_310.method_1551();
        class_327 tr = mc.field_1772;
        final long now = class_156.method_658();
        float dt = lastFrame == 0 ? 0.016f : Math.min(0.1f, (now - lastFrame) / 1000f);
        lastFrame = now;
        LIST.removeIf(n -> now - n.born > IN_MS + HOLD_MS + OUT_MS);

        int sw = ctx.method_51421(), sh = ctx.method_51443();
        int count = LIST.size();
        boolean right = Hud.notifRight(), bottom = Hud.notifBottom();
        // po zmianie rozmiaru okna powiadomienie nie moze wyjechac poza ekran
        int mx = Math.min(Hud.notifX(), Math.max(0, sw - 40));
        int my = Math.min(Hud.notifY(), Math.max(0, sh - H));
        for (int i = 0; i < count; i++) {
            Notif n = LIST.get(i);
            // najnowsze powiadomienie przy krawedzi; reszta ukladana w kierunku srodka ekranu
            float targetY = bottom ? sh - my - H - (count - 1 - i) * (H + GAP)
                                   : my + (count - 1 - i) * (H + GAP);
            if (n.y < 0) n.y = targetY;
            else n.y += (targetY - n.y) * (1f - (float) Math.exp(-dt * 14f));

            int w = cardWidth(tr, n.name, n.on);

            // wsuwanie z prawej krawedzi, na koncu wysuwanie
            long age = now - n.born;
            float off = 0f;
            if (age < IN_MS) {
                float p = 1f - age / (float) IN_MS;
                off = p * p * p;
            } else if (age > IN_MS + HOLD_MS) {
                float p = (age - IN_MS - HOLD_MS) / (float) OUT_MS;
                off = p * p * p;
            }
            int slide = Math.round(off * (w + mx + 6));
            int x = right ? sw - mx - w + slide : mx - slide;
            int y = Math.round(n.y);

            drawCard(ctx, tr, x, y, w, n.name, n.on);
        }
    }
}
