package com.example.orangeclient.module;

import com.example.orangeclient.module.render.GuiModule;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/** Obsluga klawiszy przypisanych do modulow (Toggle / Hold). Wywolywane co klatke. */
public final class Keybinds {
    private Keybinds() { }

    public static void poll(class_310 mc) {
        if (mc.method_22683() == null) return;
        long handle = mc.method_22683().method_4490();
        boolean noScreen = mc.field_1755 == null;   // w czacie / GUI klawisze nie odpalaja modulow

        for (Module m : ModuleManager.all()) {
            class_3675.class_306 key = m.getBind();
            if (key == null) {
                m.bindDown = false;
                continue;
            }
            boolean down = isDown(handle, key);
            if (down == m.bindDown) continue;
            m.bindDown = down;

            if (m instanceof GuiModule) {                  // modul GUI: bind otwiera menu (tryb Hold/Toggle nie ma znaczenia)
                if (down && noScreen) GuiModule.requestOpen();
                continue;
            }

            if (m.getBindMode() == BindMode.HOLD) {
                if (down && noScreen) m.setEnabled(true);
                else if (!down) m.setEnabled(false);
            } else if (down && noScreen) {
                m.toggle();
            }
        }
    }

    private static boolean isDown(long handle, class_3675.class_306 key) {
        if (key.method_1442() == class_3675.class_307.field_1672) {
            return GLFW.glfwGetMouseButton(handle, key.method_1444()) == GLFW.GLFW_PRESS;
        }
        return class_3675.method_15987(handle, key.method_1444());
    }
}
