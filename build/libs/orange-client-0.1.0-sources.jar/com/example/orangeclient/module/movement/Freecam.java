package com.example.orangeclient.module.movement;

import com.example.orangeclient.module.Category;
import com.example.orangeclient.module.Module;
import com.example.orangeclient.setting.BoolSetting;
import com.example.orangeclient.setting.NumberSetting;
import net.minecraft.class_243;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/**
 * Wolna kamera: ty zostajesz w miejscu (serwer widzi gracza stojacego), a kamere latasz klawiszami ruchu,
 * Spacja = w gore, Shift = w dol. Mysz obraca kamere. Dzialanie zapewniaja CameraMixin i EntityMixin.
 */
public class Freecam extends Module {
    private static Freecam instance;

    /** Predkosc: 1.0 = ok. 10 blokow/s (tyle co lot w creative), max 10.0 = ok. 100 blokow/s. */
    private final NumberSetting speed = add(new NumberSetting("Speed", 1.0, 0.1, 10.0, 0.1));
    /** Blokuje klikniecia (bicie / uzywanie przedmiotow), zeby nie robic nic gdy patrzysz z kamery. */
    private final BoolSetting blockActions = add(new BoolSetting("BlockActions", true));
    private final BoolSetting stopOnDamage = add(new BoolSetting("StopOnDamage", true));

    private boolean active;
    private class_243 pos = class_243.field_1353, prevPos = class_243.field_1353;
    private float yaw, pitch;
    private float lastHealth;

    public Freecam() {
        super("Freecam", Category.MOVEMENT);
        instance = this;
    }

    // ---- API dla mixinow
    public static boolean isActive() { return instance != null && instance.active; }
    public static class_243 cameraPos(float tickDelta) { return instance.prevPos.method_35590(instance.pos, tickDelta); }
    public static float cameraYaw() { return instance.yaw; }
    public static float cameraPitch() { return instance.pitch; }

    public static void look(double dx, double dy) {
        Freecam f = instance;
        if (f == null) return;
        f.yaw += (float) dx * 0.15f;
        f.pitch = class_3532.method_15363(f.pitch + (float) dy * 0.15f, -90f, 90f);
    }

    @Override
    protected void onEnable() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null) {      // np. wczytanie configu przy starcie gry
            setEnabled(false);
            return;
        }
        pos = prevPos = mc.field_1724.method_33571();
        yaw = mc.field_1724.method_36454();
        pitch = mc.field_1724.method_36455();
        lastHealth = mc.field_1724.method_6032();
        active = true;
    }

    @Override
    protected void onDisable() {
        active = false;
        class_304.method_1424();                 // przywroc prawdziwy stan klawiszy
    }

    @Override
    public void onPreTick(class_310 mc) {
        if (!active) return;
        if (mc.field_1724 == null || mc.field_1687 == null) {
            setEnabled(false);
            return;
        }
        if (stopOnDamage.get() && mc.field_1724.method_6032() < lastHealth - 0.01f) {
            setEnabled(false);
            return;
        }
        lastHealth = mc.field_1724.method_6032();

        class_315 o = mc.field_1690;
        prevPos = pos;

        // ruch kamery: czytamy prawdziwy stan klawiszy
        if (mc.field_1755 == null) {
            long h = mc.method_22683().method_4490();
            double fwd = (down(o.field_1894, h) ? 1 : 0) - (down(o.field_1881, h) ? 1 : 0);
            double side = (down(o.field_1849, h) ? 1 : 0) - (down(o.field_1913, h) ? 1 : 0);
            double up = (down(o.field_1903, h) ? 1 : 0) - (down(o.field_1832, h) ? 1 : 0);

            double yawRad = Math.toRadians(yaw);
            class_243 look = class_243.method_1030(pitch, yaw);
            class_243 right = new class_243(-Math.cos(yawRad), 0, -Math.sin(yawRad));
            class_243 move = look.method_1021(fwd).method_1019(right.method_1021(side)).method_1031(0, up, 0);
            if (move.method_1027() > 1.0E-6) {
                pos = pos.method_1019(move.method_1029().method_1021(speed.get() * 0.5));
            }
        }

        // gracz ma stac w miejscu: odpinamy od niego klawisze ruchu
        o.field_1894.method_23481(false);
        o.field_1881.method_23481(false);
        o.field_1913.method_23481(false);
        o.field_1849.method_23481(false);
        o.field_1903.method_23481(false);
        o.field_1832.method_23481(false);
        o.field_1867.method_23481(false);

        if (blockActions.get()) {
            o.field_1886.method_23481(false);
            o.field_1904.method_23481(false);
            while (o.field_1886.method_1436()) { }
            while (o.field_1904.method_1436()) { }
        }
    }

    private static boolean down(class_304 kb, long handle) {
        class_3675.class_306 k = class_3675.method_15981(kb.method_1428());
        if (k.method_1442() == class_3675.class_307.field_1672) {
            return GLFW.glfwGetMouseButton(handle, k.method_1444()) == GLFW.GLFW_PRESS;
        }
        if (k.method_1444() == GLFW.GLFW_KEY_UNKNOWN) return false;
        return class_3675.method_15987(handle, k.method_1444());
    }
}
