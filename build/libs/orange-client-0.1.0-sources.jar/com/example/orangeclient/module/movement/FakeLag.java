package com.example.orangeclient.module.movement;

import com.example.orangeclient.module.Category;
import com.example.orangeclient.module.Module;
import com.example.orangeclient.setting.BoolSetting;
import com.example.orangeclient.setting.ModeSetting;
import com.example.orangeclient.setting.NumberSetting;
import java.util.ArrayDeque;
import net.minecraft.class_1657;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_2824;
import net.minecraft.class_310;
import net.minecraft.class_7648;

/**
 * FakeLag: wstrzymuje pakiety wychodzace do serwera na krotki czas, a potem wysyla je wszystkie naraz w tej samej
 * kolejnosci. Dla innych graczy wygladasz, jakbys sie "teleportowal" co jakis czas.
 * Pakiety przechwytuje ClientConnectionMixin (metoda send).
 */
public class FakeLag extends Module {
    private final NumberSetting delay = add(new NumberSetting("Delay", 150, 50, 1000, 10));
    /** Always = zawsze, Near = tylko gdy w poblizu jest inny gracz. */
    private final ModeSetting mode = add(new ModeSetting("Mode", "Always", "Always", "Near"));
    private final NumberSetting nearRange = add(new NumberSetting("NearRange", 8, 2, 20, 1));
    private final BoolSetting releaseOnAttack = add(new BoolSetting("ReleaseOnAttack", true));
    private final BoolSetting releaseOnHurt = add(new BoolSetting("ReleaseOnHurt", true));

    private record Held(class_2596<?> packet, class_7648 callbacks) { }

    private final ArrayDeque<Held> queue = new ArrayDeque<>();
    private class_2535 conn;
    private long firstHeldAt;
    /** true podczas wysylania zakolejkowanych pakietow - mixin ich wtedy nie przechwytuje. */
    private boolean flushing;
    /** Po ataku nie wstrzymujemy reszty tego ticku (np. pakietu machniecia reka). */
    private boolean pausedThisTick;

    public FakeLag() {
        super("FakeLag", Category.MOVEMENT);
    }

    @Override
    protected void onDisable() {
        flush();
    }

    @Override
    public void onPreTick(class_310 mc) {
        pausedThisTick = false;
    }

    @Override
    public void onTick(class_310 mc) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.method_1562() == null) {
            // wyszlismy ze swiata/serwera - nic nie wysylamy, tylko czyscimy
            queue.clear();
            conn = null;
            return;
        }
        if (queue.isEmpty()) return;
        if (releaseOnHurt.get() && mc.field_1724.field_6235 > 0) { flush(); return; }
        if (System.currentTimeMillis() - firstHeldAt >= delay.get()) flush();
    }

    /**
     * Wolane z mixina. Zwraca true, jesli pakiet zostal przejety (mixin ma anulowac wysylke).
     */
    public boolean intercept(class_2535 connection, class_2596<?> packet, class_7648 callbacks) {
        if (flushing) return false;
        class_310 mc = class_310.method_1551();
        if (!mc.method_18854() || mc.field_1724 == null || mc.field_1687 == null || mc.method_1562() == null) return false;
        if (connection != mc.method_1562().method_48296()) return false;

        if (releaseOnAttack.get() && packet instanceof class_2824) {
            // najpierw to, co zalegalo (pozycja), potem atak, a reszta tego ticku leci bez wstrzymywania
            conn = connection;
            flush();
            pausedThisTick = true;
            return false;
        }
        if (pausedThisTick) return false;

        // zachowanie kolejnosci: jesli cos juz czeka, kazdy kolejny pakiet tez musi poczekac
        if (queue.isEmpty() && !shouldLag(mc)) return false;

        if (queue.isEmpty()) firstHeldAt = System.currentTimeMillis();
        conn = connection;
        queue.add(new Held(packet, callbacks));
        return true;
    }

    private boolean shouldLag(class_310 mc) {
        if (mode.is("Always")) return true;
        double r = nearRange.get();
        for (class_1657 other : mc.field_1687.method_18456()) {
            if (other == mc.field_1724) continue;
            if (mc.field_1724.method_5858(other) <= r * r) return true;
        }
        return false;
    }

    /** Wysyla wszystkie wstrzymane pakiety w oryginalnej kolejnosci. */
    private void flush() {
        if (queue.isEmpty()) return;
        class_2535 c = conn;
        class_310 mc = class_310.method_1551();
        if (c == null || mc.method_1562() == null || c != mc.method_1562().method_48296() || !c.method_10758()) {
            queue.clear();
            return;
        }
        flushing = true;
        try {
            Held h;
            while ((h = queue.poll()) != null) c.method_52906(h.packet(), h.callbacks(), true);
        } finally {
            flushing = false;
        }
    }
}
