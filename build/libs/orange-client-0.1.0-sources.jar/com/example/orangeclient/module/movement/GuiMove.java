package com.example.orangeclient.module.movement;

import com.example.orangeclient.module.Category;
import com.example.orangeclient.module.Module;
import com.example.orangeclient.setting.BoolSetting;
import com.example.orangeclient.setting.NumberSetting;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_465;
import org.lwjgl.glfw.GLFW;

/**
 * GuiMove: mozesz sie poruszac (WASD, Spacja, Sprint) z otwartym ekwipunkiem / skrzynia / innym oknem przedmiotow.
 * Vanilla zeruje stan klawiszy przy otwarciu ekranu - tu odczytujemy prawdziwy stan klawiszy z GLFW
 * i ustawiamy go tuz przed odczytem inputu gracza (hook w ClientPlayerEntityMixin#tickMovement).
 * Dziala tylko w oknach z przedmiotami (HandledScreen) i nigdy gdy aktywne jest pole tekstowe
 * (wyszukiwarka w creative, nazwa w kowadle itp.) - czat, tabliczki, ksiazki i menu klienta sa pomijane.
 */
public class GuiMove extends Module {
    private final BoolSetting sprint = add(new BoolSetting("Sprint", true));
    private final BoolSetting sneak = add(new BoolSetting("Sneak", false));
    /** Strzalki obracaja kamera, gdy mysz jest zajeta kursorem w oknie. */
    private final BoolSetting arrowLook = add(new BoolSetting("ArrowLook", true));
    /** Stopnie na tick (20 tickow = 1 s), czyli 4 = 80 stopni/s. */
    private final NumberSetting lookSpeed = add(new NumberSetting("LookSpeed", 4, 1, 10, 0.5));

    public GuiMove() {
        super("GuiMove", Category.MOVEMENT);
    }

    @Override
    protected void onDisable() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1755 == null) return;      // po zamknieciu okna vanilla sama odswieza stan klawiszy
        class_315 o = mc.field_1690;
        for (class_304 kb : new class_304[]{o.field_1894, o.field_1881, o.field_1913, o.field_1849, o.field_1903, o.field_1867, o.field_1832}) {
            kb.method_23481(false);
        }
    }

    /** Wywolywane z mixinu na poczatku ClientPlayerEntity#tickMovement (tuz przed odczytem inputu). */
    public void syncKeys(class_310 mc) {
        class_437 screen = mc.field_1755;
        if (screen == null || mc.field_1724 == null || mc.method_22683() == null) return;
        if (Freecam.isActive()) return;            // Freecam sam odpina klawisze od gracza
        if (!allowed(screen)) return;

        long h = mc.method_22683().method_4490();
        class_315 o = mc.field_1690;

        o.field_1894.method_23481(down(o.field_1894, h));
        o.field_1881.method_23481(down(o.field_1881, h));
        o.field_1913.method_23481(down(o.field_1913, h));
        o.field_1849.method_23481(down(o.field_1849, h));
        o.field_1903.method_23481(down(o.field_1903, h));
        if (sprint.get()) o.field_1867.method_23481(down(o.field_1867, h));
        if (sneak.get()) o.field_1832.method_23481(down(o.field_1832, h));

        if (arrowLook.get()) {
            float speed = (float) lookSpeed.get();
            float dYaw = (isKey(h, GLFW.GLFW_KEY_RIGHT) ? speed : 0) - (isKey(h, GLFW.GLFW_KEY_LEFT) ? speed : 0);
            float dPitch = (isKey(h, GLFW.GLFW_KEY_DOWN) ? speed : 0) - (isKey(h, GLFW.GLFW_KEY_UP) ? speed : 0);
            if (dYaw != 0) mc.field_1724.method_36456(mc.field_1724.method_36454() + dYaw);
            if (dPitch != 0) mc.field_1724.method_36457(class_3532.method_15363(mc.field_1724.method_36455() + dPitch, -90f, 90f));
        }
    }

    /** Okna z przedmiotami, ale nie gdy gracz cos wpisuje. */
    private static boolean allowed(class_437 screen) {
        if (!(screen instanceof class_465<?>)) return false;
        return !(screen.method_25399() instanceof class_342);
    }

    private static boolean isKey(long handle, int code) {
        return class_3675.method_15987(handle, code);
    }

    private static boolean down(class_304 kb, long handle) {
        class_3675.class_306 k = class_3675.method_15981(kb.method_1428());
        if (k.method_1442() == class_3675.class_307.field_1672) {
            return GLFW.glfwGetMouseButton(handle, k.method_1444()) == GLFW.GLFW_PRESS;
        }
        if (k.method_1444() == GLFW.GLFW_KEY_UNKNOWN) return false;
        return class_3675.method_15987(handle, k.method_1444());
    }
}
