package com.example.orangeclient.module.movement;

import com.example.orangeclient.module.Category;
import com.example.orangeclient.module.Module;
import net.minecraft.class_304;
import net.minecraft.class_310;

/**
 * AutoSprint: biegniesz, gdy idziesz do przodu, bez trzymania klawisza sprintu.
 * Zamiast wymuszac sprint recznie, wciskamy klawisz sprintu przed odczytem inputu gracza,
 * wiec reszte warunkow (glod, sneak, uzywanie przedmiotu, kolizja) sprawdza sam Minecraft.
 */
public class Sprint extends Module {
    public Sprint() {
        super("Sprint", Category.MOVEMENT);
    }

    @Override
    public void onPreTick(class_310 mc) {
        if (mc.field_1724 == null || Freecam.isActive()) return;   // w Freecam klawisze sa odpiete od gracza
        mc.field_1690.field_1867.method_23481(true);
    }

    @Override
    protected void onDisable() {
        class_304.method_1424();                      // przywroc prawdziwy stan klawiszy
    }
}
