package com.example.orangeclient.module.movement;

import com.example.orangeclient.mixin.LivingEntityAccessor;
import com.example.orangeclient.module.Category;
import com.example.orangeclient.module.Module;
import net.minecraft.class_310;

/** Usuwa opoznienie miedzy skokami (vanilla: 10 tickow) - przy trzymanej spacji skaczesz od razu po wyladowaniu. */
public class NoJumpDelay extends Module {
    public NoJumpDelay() {
        super("NoJumpDelay", Category.MOVEMENT);
    }

    @Override
    public void onPreTick(class_310 mc) {
        reset(mc);
    }

    @Override
    public void onTick(class_310 mc) {
        reset(mc);
    }

    private static void reset(class_310 mc) {
        if (mc.field_1724 == null) return;
        LivingEntityAccessor acc = (LivingEntityAccessor) mc.field_1724;
        if (acc.getJumpingCooldown() != 0) acc.setJumpingCooldown(0);
    }
}
