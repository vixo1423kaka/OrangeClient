package com.example.orangeclient.module.player;

import com.example.orangeclient.OrangeClient;
import com.example.orangeclient.module.Category;
import com.example.orangeclient.module.Module;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3965;

/**
 * Port moda "Error Killer" (errorkiller 1.11.1 dla MC 1.21.4, autor: sigmapowazna, licencja MIT) na modul klienta.
 *
 * Gdy stawiasz blok i miejsce docelowe jest "blokiem-celem" (ta sama klasa, co w oryginalnym modzie),
 * zwykle uzycie jest anulowane, a zamiast niego - wszystko w jednym ticku:
 *   1) przelaczamy sie na wiadro z woda/lawa z paska i uzywamy je (postawienie plynu),
 *   2) uzywamy je ponownie (odebranie plynu),
 *   3) wracamy na slot z blokiem i stawiamy blok w to samo miejsce.
 */
public class ErrorKiller extends Module {
    /** Klasa "bloku-celu" z oryginalnego moda (net.minecraft.class_2401), rozwiazywana niezaleznie od mapowan. */
    private static Class<?> targetClass;
    private static boolean targetResolved;

    public ErrorKiller() {
        super("ErrorKiller", Category.PLAYER);
    }

    /**
     * Wywolywane z mixina na poczatku MinecraftClient#doItemUse.
     * @return true, jesli zwykle uzycie przedmiotu ma zostac anulowane
     */
    public boolean tryIntercept(class_310 mc) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null || mc.field_1765 == null) return false;
        if (mc.field_1765.method_17783() != class_239.class_240.field_1332) return false;

        class_1799 main = mc.field_1724.method_5998(class_1268.field_5808);
        if (!(main.method_7909() instanceof class_1747)) return false;

        class_3965 target = (class_3965) mc.field_1765;
        class_2338 placePos = target.method_17777().method_10093(target.method_17780());
        if (!isTargetBlock(mc.field_1687.method_8320(placePos).method_26204())) return false;

        run(mc, target, mc.field_1724.method_31548().field_7545);
        return true;
    }

    private void run(class_310 mc, class_3965 target, int blockSlot) {
        int liquidSlot = -1;
        for (int i = 0; i < 9; i++) {
            class_1799 s = mc.field_1724.method_31548().method_5438(i);
            if (s.method_31574(class_1802.field_8705) || s.method_31574(class_1802.field_8187)) {
                liquidSlot = i;
                break;
            }
        }
        if (liquidSlot == -1) {
            mc.field_1724.method_7353(class_2561.method_43470("§c[Error Killer] No water or lava bucket in hotbar!"), true);
            return;
        }

        int prev = mc.field_1724.method_31548().field_7545;
        mc.field_1724.method_31548().field_7545 = liquidSlot;
        mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808); // postaw plyn
        mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808); // odbierz plyn
        mc.field_1724.method_31548().field_7545 = blockSlot;
        mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, target);
        mc.field_1724.method_31548().field_7545 = prev;
    }

    private static boolean isTargetBlock(class_2248 block) {
        if (!targetResolved) {
            targetResolved = true;
            try {
                String name = FabricLoader.getInstance().getMappingResolver()
                        .mapClassName("intermediary", "net.minecraft.class_2401");
                targetClass = Class.forName(name);
            } catch (Throwable t) {
                OrangeClient.LOGGER.error("ErrorKiller: nie udalo sie rozwiazac klasy bloku-celu", t);
            }
        }
        return targetClass != null && targetClass.isInstance(block);
    }
}
