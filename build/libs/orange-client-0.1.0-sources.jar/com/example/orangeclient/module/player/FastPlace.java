package com.example.orangeclient.module.player;

import com.example.orangeclient.mixin.MinecraftClientAccessor;
import com.example.orangeclient.module.Category;
import com.example.orangeclient.module.Module;
import com.example.orangeclient.setting.BoolSetting;
import com.example.orangeclient.setting.NumberSetting;
import net.minecraft.class_1747;
import net.minecraft.class_310;

public class FastPlace extends Module {
    /** Odstep miedzy uzyciami w tickach: 1 = co tick (najszybciej), 4 = vanilla. */
    private final NumberSetting delay = add(new NumberSetting("Delay", 1, 1, 4, 1));
    /** Przyspiesza tylko gdy trzymasz blok (nie jedzenie, perly itp.). */
    private final BoolSetting onlyBlocks = add(new BoolSetting("OnlyBlocks", true));

    public FastPlace() {
        super("FastPlace", Category.PLAYER);
    }

    @Override
    public void onTick(class_310 mc) {
        if (mc.field_1724 == null) return;
        if (onlyBlocks.get()
                && !(mc.field_1724.method_6047().method_7909() instanceof class_1747)
                && !(mc.field_1724.method_6079().method_7909() instanceof class_1747)) return;

        MinecraftClientAccessor acc = (MinecraftClientAccessor) mc;
        int max = (int) delay.get();
        if (acc.getItemUseCooldown() > max) acc.setItemUseCooldown(max);
    }
}
