package com.example.orangeclient.module.player;

import com.example.orangeclient.module.Category;
import com.example.orangeclient.module.Module;
import com.example.orangeclient.module.ModuleManager;
import com.example.orangeclient.module.combat.TriggerBot;
import com.example.orangeclient.module.movement.Freecam;
import com.example.orangeclient.setting.BoolSetting;
import net.minecraft.class_1297;
import net.minecraft.class_1533;
import net.minecraft.class_1534;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1688;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2238;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2288;
import net.minecraft.class_2336;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2478;
import net.minecraft.class_2515;
import net.minecraft.class_2680;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3481;
import net.minecraft.class_3489;
import net.minecraft.class_3675;
import net.minecraft.class_3715;
import net.minecraft.class_3748;
import net.minecraft.class_3965;
import net.minecraft.class_6862;
import net.minecraft.class_8886;
import org.lwjgl.glfw.GLFW;

/**
 * AntiTrap:
 *  1) Encje (gracze, moby, itemy w ramkach itd.) przestaja blokowac celownik:
 *     klikasz/kopiesz/stawiasz "przez" nie, prosto w blok za nimi.
 *     TriggerBot potrzebuje encji w celowniku, wiec gdy jest wlaczony, ta czesc sie nie wtraca.
 *  2) Z Twojego punktu widzenia (tylko po stronie klienta) znikaja obrazy, item framey
 *     (takze glow item framey) i wszystkie rodzaje minecartow.
 *  3) PPM na bloki z GUI (skrzynki, tabliczki, piece, crafting, hopper...) nic nie otwiera.
 *  4) Automatycznie niszczy pulapki pod Toba:
 *      - stoisz na plotku (takze gdy stoi na nim cobweb, w ktorym tkwisz) -> wyjmuje siekiere i niszczy PLOTEK,
 *        a jesli w tym miejscu jest cobweb, to kopie "przez" niego prosto w plotek (cobweb zostaje nietkniety),
 *      - tkwisz w cobwebie (albo jest tuz pod Toba) i nie ma pod nim plotka -> niszczy cobweb (wyjmuje na niego MIECZ, a bez miecza siekiere).
 *     Kopanie robi sam Minecraft (my tylko podstawiamy mu cel i wciskamy LPM), wiec postep, pakiety
 *     i animacje sa takie jak przy recznym kopaniu.
 */
public class AntiTrap extends Module {
    private final BoolSetting breakFence = add(new BoolSetting("BreakFence", true));
    private final BoolSetting breakWeb = add(new BoolSetting("BreakCobweb", true));
    /** Po zniszczeniu pulapki wraca do slotu, ktory trzymales wczesniej. */
    private final BoolSetting switchBack = add(new BoolSetting("SwitchBack", true));
    /** PPM na skrzynke, tabliczke, piec, crafting itp. nie otwiera GUI (z Shiftem + przedmiotem w rece stawiasz blok jak w vanilli). */
    private final BoolSetting noBlockGui = add(new BoolSetting("NoBlockGui", true));

    private int prevSlot = -1;
    private int autoSlot = -1;
    /** Czy w tym ticku podstawialismy kopanie (zeby potem przywrocic prawdziwy stan LPM). */
    private boolean forcing;
    /** Pulapka, ktora aktualnie kopiemy - GameRendererMixin podstawia ja jako cel celownika (patrz forcedHit). */
    private static volatile class_3965 forcedHit;

    public AntiTrap() {
        super("AntiTrap", Category.PLAYER);
    }

    @Override
    protected void onDisable() {
        stopBreaking(class_310.method_1551());
    }

    /** Na poczatku ticku, przed obsluga klikniec - wtedy vanilla zajmuje sie samym kopaniem. */
    @Override
    public void onPreTick(class_310 mc) {
        class_2338 target = findTarget(mc);
        if (target == null) {
            stopBreaking(mc);
            return;
        }
        selectTool(mc, mc.field_1687.method_8320(target));
        forcing = true;
        mc.field_1690.field_1886.method_23481(true);
        // Celownik na pulapke, nawet jesli cobweb jest "po drodze" (serwer nie sprawdza, czy cos zaslania blok).
        // Samo ustawienie mc.crosshairTarget tutaj nie wystarcza - vanilla przelicza celownik w tym samym ticku
        // (juz po START_CLIENT_TICK) i nadpisuje go cobwebem. Dlatego cel podstawia GameRendererMixin
        // w findCrosshairTarget, a my ustawiamy go tez od razu (na wypadek kolejnosci wywolan).
        forcedHit = new class_3965(
                new class_243(target.method_10263() + 0.5, target.method_10264() + 1.0, target.method_10260() + 0.5),
                class_2350.field_11036, target, false);
        mc.field_1765 = forcedHit;
    }

    /** Cel wymuszony przez AntiTrap (kopanie pulapki "przez" cobweb) albo null. Uzywane przez GameRendererMixin. */
    public static class_3965 forcedHit() {
        return forcedHit;
    }

    /** Pulapka do zniszczenia: najpierw plotek pod Toba (takze przez cobweb), potem cobweb. */
    private class_2338 findTarget(class_310 mc) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return null;
        if (mc.field_1755 != null || Freecam.isActive()) return null;
        if (mc.field_1724.method_7325() || mc.field_1724.method_6115()) return null;

        class_2338 feet = mc.field_1724.method_24515();      // stojac na plotku (kolizja 1,5 bloku) jest to blok NAD plotkiem
        class_2338 under = feet.method_10074();
        class_2680 feetState = mc.field_1687.method_8320(feet);
        class_2680 underState = mc.field_1687.method_8320(under);

        // plotek pod Toba - nawet gdy w Twoim bloku stoi cobweb (wtedy kopiemy przez niego)
        // Nie czekamy na ladowanie: wpadajac w cobweb nad plotkiem gracz jest juz w cobwebie (feet), a plotek
        // tuz pod nim, wiec kopiemy plotek od razu - bez warunku isOnGround().
        boolean inWeb = feetState.method_27852(class_2246.field_10343);
        if (breakFence.get() && underState.method_26164(class_3481.field_16584) && (mc.field_1724.method_24828() || inWeb)) return under;
        if (breakWeb.get() && inWeb) return feet;
        if (breakWeb.get() && underState.method_27852(class_2246.field_10343)) return under;
        return null;
    }

    /**
     * Wyjmuje narzedzie z paska: miecz na cobweba, siekiere na plotek
     * (jesli AutoTool jest wlaczony, to on decyduje o narzedziu).
     */
    private void selectTool(class_310 mc, class_2680 state) {
        AutoTool autoTool = ModuleManager.get(AutoTool.class);
        if (autoTool != null && autoTool.isEnabled()) return;

        class_1661 inv = mc.field_1724.method_31548();
        int cur = inv.field_7545;
        int bestAxe = pickBest(inv, state, state.method_27852(class_2246.field_10343) ? class_3489.field_42611 : class_3489.field_42612);
        // brak miecza na pasku -> cobweba tez da sie zniszczyc siekiera
        if (bestAxe == -1 && state.method_27852(class_2246.field_10343)) bestAxe = pickBest(inv, state, class_3489.field_42612);
        if (bestAxe != -1 && bestAxe != cur) {
            if (prevSlot == -1) prevSlot = cur;
            inv.field_7545 = bestAxe;
            autoSlot = bestAxe;
        }
    }

    /** Slot paska z najszybszym narzedziem z danego tagu (albo -1). */
    private static int pickBest(class_1661 inv, class_2680 state, class_6862<class_1792> tag) {
        int best = -1;
        float bestSpeed = 0f;
        for (int i = 0; i < 9; i++) {
            class_1799 st = inv.method_5438(i);
            if (st.method_7960() || !st.method_31573(tag)) continue;
            if (st.method_7963() && st.method_7936() - st.method_7919() <= 1) continue;   // nie psujemy ostatniego uzycia
            float speed = st.method_7924(state);
            if (speed > bestSpeed) {
                bestSpeed = speed;
                best = i;
            }
        }
        return best;
    }

    private void stopBreaking(class_310 mc) {
        forcedHit = null;
        if (forcing) {
            forcing = false;
            // KeyBinding.updatePressedStates() obsluguje tylko klawiature, nie przyciski myszy - LPM zostawal
            // "wcisniety" po zniszczeniu pulapki. Dlatego przywracamy prawdziwy stan recznie.
            if (mc != null) restoreAttackKey(mc);
        }
        if (prevSlot != -1 && mc != null && mc.field_1724 != null) {
            class_1661 inv = mc.field_1724.method_31548();
            // wracamy tylko, jesli gracz sam nie zmienil slotu w miedzyczasie
            if (switchBack.get() && inv.field_7545 == autoSlot) inv.field_7545 = prevSlot;
        }
        prevSlot = -1;
        autoSlot = -1;
    }

    /** Ustawia attackKey na to, co faktycznie robi gracz (fizyczny stan klawisza/przycisku myszy). */
    private static void restoreAttackKey(class_310 mc) {
        class_304 kb = mc.field_1690.field_1886;
        if (mc.field_1755 != null) {
            kb.method_23481(false);
            return;
        }
        long handle = mc.method_22683().method_4490();
        class_3675.class_306 k = class_3675.method_15981(kb.method_1428());
        boolean down;
        if (k.method_1442() == class_3675.class_307.field_1672) {
            down = GLFW.glfwGetMouseButton(handle, k.method_1444()) == GLFW.GLFW_PRESS;
        } else if (k.method_1444() == GLFW.GLFW_KEY_UNKNOWN) {
            down = false;
        } else {
            down = class_3675.method_15987(handle, k.method_1444());
        }
        kb.method_23481(down);
    }

    /** Czy kliknieciu PPM w ten blok trzeba zablokowac (bo otworzyloby GUI). Uzywane przez ClientPlayerInteractionManagerMixin. */
    public static boolean blocksGui(class_1657 player, class_3965 hit) {
        AntiTrap m = ModuleManager.get(AntiTrap.class);
        if (m == null || !m.isEnabled() || !m.noBlockGui.get()) return false;
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || hit == null) return false;
        // Shift + cos w rece: vanilla i tak pomija GUI bloku (stawianie blokow przy skrzynce) - nie wtracamy sie
        if (player.method_5715() && !(player.method_6047().method_7960() && player.method_6079().method_7960())) return false;
        return opensGui(mc.field_1687, hit.method_17777());
    }

    private static boolean opensGui(class_1937 world, class_2338 pos) {
        class_2680 st = world.method_8320(pos);
        class_2248 b = st.method_26204();
        if (b instanceof class_2478 || b instanceof class_2336 || b instanceof class_2288
                || b instanceof class_2515 || b instanceof class_3748 || b instanceof class_3715
                || b instanceof class_2238 || b instanceof class_8886) return true;
        // skrzynki, beczki, shulkery, piece, hoppery, dispensery, crafting table, kowadla, enchanting itd.
        return st.method_26196(world, pos) != null;
    }

    /** Czy encje maja przestac blokowac celownik. */
    public static boolean active() {
        AntiTrap m = ModuleManager.get(AntiTrap.class);
        if (m == null || !m.isEnabled()) return false;
        TriggerBot tb = ModuleManager.get(TriggerBot.class);
        return tb == null || !tb.isEnabled();
    }

    /** Czy dana encja ma byc niewidoczna (obraz, item frame, dowolny minecart). */
    public static boolean hides(class_1297 entity) {
        if (!(entity instanceof class_1688
                || entity instanceof class_1533      // obejmuje tez GlowItemFrameEntity
                || entity instanceof class_1534)) return false;
        AntiTrap m = ModuleManager.get(AntiTrap.class);
        return m != null && m.isEnabled();
    }
}
