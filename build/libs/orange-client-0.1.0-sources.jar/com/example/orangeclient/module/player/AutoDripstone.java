package com.example.orangeclient.module.player;

import com.example.orangeclient.mixin.MinecraftClientAccessor;
import com.example.orangeclient.module.Category;
import com.example.orangeclient.module.Module;
import com.example.orangeclient.module.movement.Freecam;
import com.example.orangeclient.setting.NumberSetting;
import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2533;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_310;
import net.minecraft.class_3965;

/**
 * AutoDripstone (metoda jak w BK-Dripstone):
 * trzymasz PRAWY PRZYCISK MYSZY i patrzysz na ZAMKNIETA klape (trapdoor) ->
 * modul sam bierze pointed dripstone z hotbara i stawia go POD klapa, klikajac w bok bloku
 * za klapa (bez skradania), po czym wraca na poprzedni slot. Klape otwiera/zamyka zwykly
 * prawy klik, ktory trzymasz - modul tylko go przyspiesza.
 *
 * Jedyne ustawienie: Speed (1-10) - im wyzej, tym szybciej stawia dripstone i klika klape.
 *   Speed 10 = co tick, Speed 7 = tempo vanilli (4 ticki), Speed 1 = co 10 tickow.
 *
 * Wymaga pointed dripstone w hotbarze (sloty 1-9).
 */
public class AutoDripstone extends Module {
    private final NumberSetting speed = add(new NumberSetting("Speed", 10, 1, 10, 1));

    private int placeCooldown;

    public AutoDripstone() {
        super("AutoDripstone", Category.PLAYER);
    }

    @Override
    protected void onEnable() {
        placeCooldown = 0;
    }

    /** Speed 10 -> 1 tick, Speed 1 -> 10 tickow. */
    private int interval() {
        return 11 - (int) speed.get();
    }

    @Override
    public void onTick(class_310 mc) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return;
        if (placeCooldown > 0) placeCooldown--;
        if (mc.field_1755 != null || Freecam.isActive() || mc.field_1724.method_7325() || !mc.field_1724.method_5805()) return;
        if (!mc.field_1690.field_1904.method_1434()) return;

        if (!(mc.field_1765 instanceof class_3965 look) || look.method_17783() != class_239.class_240.field_1332) return;
        class_2338 trapdoorPos = look.method_17777();
        class_2680 trapdoor = mc.field_1687.method_8320(trapdoorPos);
        if (!(trapdoor.method_26204() instanceof class_2533)) return;
        if (trapdoor.method_11654(class_2741.field_12537)) return; // stawiamy tylko pod zamknieta klapa

        // szybsze klikanie klapy przez vanillowy prawy klik
        MinecraftClientAccessor acc = (MinecraftClientAccessor) mc;
        int max = interval();
        if (acc.getItemUseCooldown() > max) acc.setItemUseCooldown(max);

        if (placeCooldown > 0) return;

        class_2338 below = trapdoorPos.method_10074();
        if (!mc.field_1687.method_8320(below).method_45474()) return;

        class_2350 facing = trapdoor.method_11654(class_2741.field_12481);
        class_2338 support = below.method_10093(facing.method_10153()); // blok za klapa, na nim "opieramy" dripstone
        if (mc.field_1687.method_8320(support).method_45474()) return;

        class_1661 inv = mc.field_1724.method_31548();
        int slot = -1;
        for (int i = 0; i < 9; i++) {
            if (inv.method_5438(i).method_31574(class_1802.field_28042)) { slot = i; break; }
        }
        if (slot == -1) return;

        class_243 hitPos = new class_243(
                support.method_10263() + 0.5 + facing.method_10148() * 0.5,
                support.method_10264() + 0.5 + facing.method_10164() * 0.5,
                support.method_10260() + 0.5 + facing.method_10165() * 0.5);
        class_3965 hit = new class_3965(hitPos, facing, support, false);

        int prev = inv.field_7545;
        inv.field_7545 = slot;
        try {
            mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit); // sam zsynchronizuje slot z serwerem
        } finally {
            inv.field_7545 = prev;
        }
        placeCooldown = interval();
    }
}
