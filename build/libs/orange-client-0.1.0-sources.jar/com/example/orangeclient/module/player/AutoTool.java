package com.example.orangeclient.module.player;

import com.example.orangeclient.module.Category;
import com.example.orangeclient.module.Module;
import com.example.orangeclient.module.movement.Freecam;
import com.example.orangeclient.setting.BoolSetting;
import com.example.orangeclient.setting.NumberSetting;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;

/** Podczas kopania automatycznie wybiera z paska najlepsze narzedzie do bloku, na ktory patrzysz. */
public class AutoTool extends Module {
    /** Po skonczeniu kopania wraca do slotu, ktory trzymales wczesniej. */
    private final BoolSetting switchBack = add(new BoolSetting("SwitchBack", true));
    /** Nie wybiera narzedzi, ktore zaraz sie zepsuja (1 uzycie do konca). */
    private final BoolSetting saveBroken = add(new BoolSetting("AvoidBreaking", true));

    /** Opoznienie (w tickach, 20 = 1 s) od rozpoczecia kopania bloku do zmiany slotu. 0 = od razu. */
    private final NumberSetting delay = add(new NumberSetting("Delay", 0, 0, 20, 1));

    private int prevSlot = -1;
    private int autoSlot = -1;
    /** Ile tickow z rzedu kopiemy ten sam blok (do opoznienia). */
    private int miningTicks = 0;
    private class_2338 lastPos = null;

    public AutoTool() {
        super("AutoTool", Category.PLAYER);
    }

    @Override
    protected void onDisable() {
        restore(class_310.method_1551());
    }

    /** Na poczatku ticku, jeszcze przed obsluga klikniec - dzieki temu kopiemy od razu dobrym narzedziem. */
    @Override
    public void onPreTick(class_310 mc) {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            prevSlot = autoSlot = -1;
            miningTicks = 0;
            lastPos = null;
            return;
        }
        class_2680 state = null;
        class_2338 pos = null;
        boolean mining = mc.field_1755 == null && !Freecam.isActive() && !mc.field_1724.method_7337()
                && !mc.field_1724.method_6115() && mc.field_1690.field_1886.method_1434()
                && mc.field_1765 instanceof class_3965 bhr && bhr.method_17783() == class_239.class_240.field_1332;
        if (mining) {
            pos = ((class_3965) mc.field_1765).method_17777();
            state = mc.field_1687.method_8320(pos);
            if (state.method_26215() || state.method_26214(mc.field_1687, pos) < 0) mining = false;
        }

        if (!mining) {
            restore(mc);
            miningTicks = 0;
            lastPos = null;
            return;
        }

        // licznik opoznienia liczy sie od chwili, gdy zaczynasz kopac dany blok
        if (!pos.equals(lastPos)) {
            lastPos = pos;
            miningTicks = 0;
        }
        miningTicks++;
        if (miningTicks <= (int) delay.get()) return;

        class_1661 inv = mc.field_1724.method_31548();
        int cur = inv.field_7545;
        int best = cur;
        float bestScore = score(mc.field_1724.method_31548().method_5438(cur), state);
        for (int i = 0; i < 9; i++) {
            if (i == cur) continue;
            class_1799 st = inv.method_5438(i);
            if (saveBroken.get() && st.method_7963() && st.method_7936() - st.method_7919() <= 1) continue;
            float sc = score(st, state);
            if (sc > bestScore + 0.01f) {
                bestScore = sc;
                best = i;
            }
        }
        if (best != cur) {
            if (prevSlot == -1) prevSlot = cur;
            inv.field_7545 = best;
            autoSlot = best;
        }
    }

    /** Wyzszy wynik = lepsze narzedzie: najpierw takie, ktore daje drop z bloku, potem szybkosc kopania. */
    private static float score(class_1799 stack, class_2680 state) {
        float speed = stack.method_7924(state);
        return speed + (stack.method_7951(state) ? 1000f : 0f);
    }

    private void restore(class_310 mc) {
        if (prevSlot != -1 && mc != null && mc.field_1724 != null) {
            class_1661 inv = mc.field_1724.method_31548();
            // wracamy tylko, jesli gracz sam nie zmienil slotu w miedzyczasie
            if (switchBack.get() && inv.field_7545 == autoSlot) inv.field_7545 = prevSlot;
        }
        prevSlot = -1;
        autoSlot = -1;
    }
}
