package com.example.orangeclient.module.combat;

import com.example.orangeclient.friend.Friends;
import com.example.orangeclient.mixin.LivingEntityAccessor;
import com.example.orangeclient.module.Category;
import com.example.orangeclient.module.Module;
import com.example.orangeclient.module.movement.Freecam;
import com.example.orangeclient.setting.BoolSetting;
import com.example.orangeclient.setting.ColorSetting;
import com.example.orangeclient.setting.ModeSetting;
import com.example.orangeclient.setting.NumberSetting;
import com.example.orangeclient.util.RenderUtil;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_3489;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import org.joml.Matrix4f;

import java.util.concurrent.ThreadLocalRandom;

/**
 * KillAura z rozbudowanymi ustawieniami: wybor celow, sortowanie, tempo ataku (cooldown),
 * rotacje (Smooth / Snap), ruch (Follow), warunki ataku, lamanie tarczy i wizualizacja celu.
 */
public class KillAura extends Module {
    // ---------- Targeting ----------
    private final NumberSetting range = add(new NumberSetting("Range", 3.0, 1.0, 6.0, 0.1));
    /** Zasieg, gdy miedzy Toba a celem jest sciana (0 = nie bij przez sciany). */
    private final NumberSetting wallRange = add(new NumberSetting("WallRange", 0.0, 0.0, 6.0, 0.1));
    private final NumberSetting fov = add(new NumberSetting("FOV", 180, 10, 360, 5));
    private final ModeSetting sort = add(new ModeSetting("Sort", "Closest", "Closest", "Health", "Angle", "HurtTime", "Armor"));
    /** Trzyma obecny cel, dopoki zyje i jest w zasiegu (zamiast wybierac co tick od nowa). */
    private final BoolSetting keepTarget = add(new BoolSetting("KeepTarget", false));
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting hostiles = add(new BoolSetting("Hostiles", false));
    private final BoolSetting animals = add(new BoolSetting("Animals", false));
    /** Pozostale moby: wieśniacy, golemy, zwierzeta wodne itd. */
    private final BoolSetting others = add(new BoolSetting("Others", false));
    private final BoolSetting invisibles = add(new BoolSetting("Invisibles", true));
    /** Gracze bez zadnego elementu zbroi. */
    private final BoolSetting naked = add(new BoolSetting("Naked", true));
    private final BoolSetting teammates = add(new BoolSetting("Teammates", false));
    private final BoolSetting ignoreFriends = add(new BoolSetting("IgnoreFriends", true));

    // ---------- Tempo ataku ----------
    private final NumberSetting minCooldown = add(new NumberSetting("MinCooldown", 0.95, 0.1, 1.0, 0.05));
    /** Dodatkowe losowe opoznienie 0..Jitter ms po kazdym uderzeniu. */
    private final NumberSetting jitter = add(new NumberSetting("Jitter", 40, 0, 300, 10));
    /** Bije tylko, gdy cel ma hurtTime <= tej wartosci (10 = wylaczone). */
    private final NumberSetting hurtTimeLimit = add(new NumberSetting("HurtTimeLimit", 10, 0, 10, 1));

    // ---------- Rotacje ----------
    private final ModeSetting rotMode = add(new ModeSetting("Rotation", "Smooth", "Smooth", "Snap", "Off"));
    private final NumberSetting rotSpeed = add(new NumberSetting("RotSpeed", 12, 1, 40, 0.5));
    private final NumberSetting maxStep = add(new NumberSetting("MaxStep", 25, 1, 90, 1));
    private final NumberSetting randomness = add(new NumberSetting("Randomness", 0.6, 0.0, 3.0, 0.1));
    private final ModeSetting aimPoint = add(new ModeSetting("AimPoint", "Chest", "Chest", "Head", "Closest"));
    /**
     * Silent: rotacja do celu idzie TYLKO do serwera (pakiety ruchu + atak), a po stronie klienta nic nie widac -
     * kamera stoi w miejscu (model gracza tez, chyba ze wlaczysz SilentModel).
     * Wylaczone = kamera sama sie obraca do celu.
     */
    private final BoolSetting silent = add(new BoolSetting("Silent", true));
    /** Tylko przy Silent: pokazuje u Ciebie (3. osoba) model obrocony do celu. Domyslnie wylaczone - klient nic nie widzi. */
    private final BoolSetting silentModel = add(new BoolSetting("SilentModel", false));

    // ---------- Warunki ----------
    /**
     * Bije tylko wtedy, gdy uderzenie bedzie krytyczne (spadasz); na ziemi nie bije wcale.
     * Na ulamek ticka wylaczany jest sprint, bo vanilla nie daje critow podczas sprintu.
     */
    private final BoolSetting onlyCrits = add(new BoolSetting("OnlyCrits", false));
    private final BoolSetting pauseOnUse = add(new BoolSetting("PauseOnUse", true));
    private final BoolSetting onlyWeapon = add(new BoolSetting("OnlyWeapon", false));
    /** Gdy cel blokuje tarcza, a masz topor na hotbarze - przelacza na niego na czas ataku. */
    private final BoolSetting breakShield = add(new BoolSetting("BreakShield", false));
    private final BoolSetting swapBack = add(new BoolSetting("SwapBack", true));

    // ---------- Ruch ----------
    /**
     * Follow: sam podchodzi do celu i krazy wokol niego - zawsze w lewo, w odleglosci {@link #CIRCLE_RADIUS}.
     * (Nazwa to tylko "Follow", ale ruch to dokladnie to, co robilo dawne Circle.)
     */
    private final BoolSetting follow = add(new BoolSetting("Follow", false));
    /** Z jakiej odleglosci (do hitboxa) KillAura zaczyna isc za celem. */
    private final NumberSetting moveRange = add(new NumberSetting("MoveRange", 8.0, 3.0, 20.0, 0.5));
    /**
     * Skacze, gdy na drodze (Follow) jest blok wyzszy niz stopien. Razem z OnlyCrits skacze tez sam
     * z ziemi, gdy cel jest w zasiegu - bez tego nie ma jak zadac critu (crit = uderzenie podczas spadania).
     */
    private final BoolSetting autoJump = add(new BoolSetting("AutoJump", true));
    /** Stala odleglosc od srodka celu podczas krazenia. */
    private static final double CIRCLE_RADIUS = 1.0;

    // ---------- Wizualizacja ----------
    private final ModeSetting targetEsp = add(new ModeSetting("TargetESP", "Ring", "Off", "Box", "Fill", "Both", "Ring"));
    private final ColorSetting espColor = add(new ColorSetting("TargetColor", 0xFF7A00, true));
    private final NumberSetting fillAlpha = add(new NumberSetting("FillAlpha", 60, 10, 200, 10));
    /** Czas jednego przejscia pierscienia (gora -> dol lub dol -> gora) w ms. */
    private final NumberSetting ringSpeed = add(new NumberSetting("RingSpeed", 1200, 400, 3000, 100));
    /** Dlugosc poswiaty za pierscieniem jako ulamek wysokosci celu. */
    private final NumberSetting ringTrail = add(new NumberSetting("RingTrail", 0.45, 0.1, 1.0, 0.05));
    private final NumberSetting ringGlow = add(new NumberSetting("RingGlow", 140, 20, 255, 10));

    private long lastHit;
    private long nextDelayMs;
    private class_1309 target;
    private double noiseYaw, noisePitch;
    private long nextNoise;

    // ---------- stan silent rotation ----------
    /** Rotacja, ktora widzi serwer (w trybie Silent). Utrzymywana miedzy tickami, zeby Smooth plynnie dochodzil do celu. */
    private float serverYaw, serverPitch;
    /** Czy w poprzednim ticku mielismy aktywna rotacje do celu. */
    private boolean rotating;
    /** Czy w tym ticku podmienilismy yaw/pitch gracza na czas wysylania pakietow (trzeba je potem przywrocic). */
    private boolean motionActive;
    private float savedYaw, savedPitch;
    /** Poprzednia rotacja serwera (do interpolacji modelu gracza miedzy tickami). */
    private float prevRotYaw, prevRotPitch;
    /** Czy na czas ataku wylaczylismy sprint (trzeba go przywrocic). */
    private boolean sprintCleared;

    // ---------- plynne celowanie (liczone co KLATKE, jak w AimAssist) ----------
    /** Wirtualna rotacja dla trybu Silent - aktualizowana co klatke, a w pakiecie ruchu idzie jej najnowsza wartosc. */
    private float vYaw, vPitch;
    private boolean vValid;
    private long lastFrameNs;

    // ---------- stan ruchu ----------
    /** Czy w tym ticku nadpisalismy klawisze ruchu (trzeba je potem przywrocic do prawdziwego stanu). */
    private boolean moveOverride;

    public KillAura() {
        super("KillAura", Category.COMBAT);
    }

    /** Aktualny cel (do uzycia np. w HUD). */
    public class_1309 getTarget() { return target; }

    @Override
    protected void onEnable() {
        lastHit = 0;
        nextDelayMs = 0;
        target = null;
        rotating = false;
        vValid = false;
        lastFrameNs = 0;
    }

    @Override
    protected void onDisable() {
        target = null;
        rotating = false;
        vValid = false;
        releaseMovement();
    }

    // ---------- ruch: Follow ----------

    /**
     * Przed odczytem inputu przez gracza ustawiamy klawisze ruchu tak, zeby krazyl wokol celu (Follow)
     * i - jesli wlaczone AutoJump - skakal przez przeszkody / pod crity. Kierunek liczymy w swiecie
     * i przeliczamy na WASD wzgledem prawdziwego yaw gracza (w trybie Silent kamera stoi w miejscu,
     * wiec to ten sam yaw, wg ktorego vanilla liczy ruch).
     */
    @Override
    public void onPreTick(class_310 mc) {
        class_1657 p = mc.field_1724;
        if (!canRun(mc, p)) { releaseMovement(); return; }

        boolean steer = false, jump = false;
        boolean fw = false, bk = false, lf = false, rt = false;
        double dirX = 0.0, dirZ = 0.0;

        class_1309 mt = follow.get() ? findMoveTarget(mc, p) : null;
        if (mt != null) {
            steer = true;
            double dx = mt.method_23317() - p.method_23317();
            double dz = mt.method_23321() - p.method_23321();
            double dist = Math.sqrt(dx * dx + dz * dz);
            double rx = dist > 1.0E-4 ? dx / dist : 0.0;   // wersor w strone celu
            double rz = dist > 1.0E-4 ? dz / dist : 0.0;

            double err = dist - CIRCLE_RADIUS;
            double radial = class_3532.method_15350(err, -1.0, 1.0);        // dociaganie / odsuwanie do promienia
            double tangent = Math.abs(err) > 2.5 ? 0.0 : 1.0;        // daleko od okregu: tylko podejscie
            // styczna "w lewo" wzgledem celu = (rz, -rx)
            double mx = rx * radial + rz * tangent;
            double mz = rz * radial - rx * tangent;

            double len = Math.sqrt(mx * mx + mz * mz);
            if (len > 0.05) {
                dirX = mx / len;
                dirZ = mz / len;
                double yaw = Math.toRadians(silent.get() && rotating ? serverYaw : p.method_36454());
                double sin = Math.sin(yaw), cos = Math.cos(yaw);
                double f = dirX * -sin + dirZ * cos;          // skladowa "do przodu"
                double side = dirX * -cos + dirZ * -sin;      // skladowa "w prawo"
                fw = f > 0.3;
                bk = f < -0.3;
                rt = side > 0.3;
                lf = side < -0.3;
            }
        }

        if (autoJump.get() && p.method_24828()) {
            if (steer && (dirX != 0.0 || dirZ != 0.0) && needsJump(mc, p, dirX, dirZ)) {
                jump = true;                                  // przeszkoda na drodze (Follow)
            } else if (!steer && target != null && manualJumpNeeded(mc, p)) {
                jump = true;                                  // przeszkoda na drodze przy recznym ruchu
            } else if (onlyCrits.get() && critTargetInRange(p)) {
                jump = true;                                  // podskok, zeby zlapac crita przy spadaniu
            }
        }

        if (!steer && !jump) { releaseMovement(); return; }

        class_304.method_1424();                     // start od prawdziwego stanu klawiszy
        class_315 o = mc.field_1690;
        if (steer) {
            o.field_1894.method_23481(fw);
            o.field_1881.method_23481(bk);
            o.field_1849.method_23481(rt);
            o.field_1913.method_23481(lf);
            if (fw) o.field_1867.method_23481(true);
        }
        if (jump) {
            o.field_1903.method_23481(true);
            forceJump(p);
        }
        moveOverride = true;
    }

    /**
     * Skok wprost, bez polegania na stanie klawisza (stan klawisza bywa nadpisywany przez inne moduly / vanille).
     * Odtwarza to, co robi vanilla przy skoku z ziemi: predkosc w gore + 10 tickow cooldownu.
     */
    private static void forceJump(class_1657 p) {
        if (!p.method_24828() || p.method_5799() || p.method_5771() || p.method_5765() || p.method_6101()) return;
        LivingEntityAccessor acc = (LivingEntityAccessor) p;
        if (acc.getJumpingCooldown() > 0) return;
        acc.invokeJump();
        acc.setJumpingCooldown(10);
    }

    /** Czy przy RECZNYM ruchu (WASD) na drodze jest blok, ktory trzeba przeskoczyc. */
    private static boolean manualJumpNeeded(class_310 mc, class_1657 p) {
        if (!(p instanceof net.minecraft.class_746 cp)) return false;
        float f = cp.field_3913.field_3905, s = cp.field_3913.field_3907;
        if (f == 0f && s == 0f) return false;
        double yaw = Math.toRadians(p.method_36454());
        double sin = Math.sin(yaw), cos = Math.cos(yaw);
        double dx = s * cos - f * sin;
        double dz = f * cos + s * sin;
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 1.0E-4) return false;
        return needsJump(mc, p, dx / len, dz / len);
    }

    private void releaseMovement() {
        if (moveOverride) {
            class_304.method_1424();         // przywroc prawdziwy stan klawiszy
            moveOverride = false;
        }
    }

    /** Czy obecny cel ataku jest na tyle blisko, ze warto podskoczyc po crita. */
    private boolean critTargetInRange(class_1657 p) {
        class_1309 t = target;
        if (t == null || !t.method_5805() || t.method_31481()) return false;
        return distanceToBox(p.method_33571(), t.method_5829()) <= range.get() + 1.0;
    }

    /**
     * Czy w kierunku ruchu stoi przeszkoda, ktorej nie przejdziemy sami (wyzsza niz stopien 0.6),
     * a po wskoczeniu na nia (ok. 1 blok) jest miejsce na cale cialo. Sprawdzamy bloki z wyprzedzeniem,
     * a nie tylko horizontalCollision, bo ta flaga potrafi migac i spozniac sie o tick.
     */
    private static boolean needsJump(class_310 mc, class_1657 p, double dirX, double dirZ) {
        class_238 b = p.method_5829();
        double dx = dirX * 0.4, dz = dirZ * 0.4;
        class_238 wall = new class_238(b.field_1323 + dx, b.field_1322 + 0.65, b.field_1321 + dz, b.field_1320 + dx, b.field_1325, b.field_1324 + dz);
        boolean blocked = p.field_5976 || mc.field_1687.method_20812(p, wall).iterator().hasNext();
        if (!blocked) return false;
        class_238 landing = new class_238(b.field_1323 + dx, b.field_1322 + 1.01, b.field_1321 + dz, b.field_1320 + dx, b.field_1325 + 1.01, b.field_1324 + dz);
        return !mc.field_1687.method_20812(p, landing).iterator().hasNext();
    }

    /** Cel do chodzenia: obecny cel ataku (jesli w zasiegu ruchu), inaczej najblizszy pasujacy. */
    private class_1309 findMoveTarget(class_310 mc, class_1657 p) {
        double reach = moveRange.get();
        class_243 eye = p.method_33571();
        if (target != null && target.method_5805() && !target.method_31481() && matchesType(p, target)
                && distanceToBox(eye, target.method_5829()) <= reach) {
            return target;
        }
        class_1309 best = null;
        double bestDist = Double.MAX_VALUE;
        for (class_1297 e : mc.field_1687.method_18112()) {
            if (!(e instanceof class_1309 le) || le == p || !le.method_5805() || le.method_31481()
                    || le.method_7325() || !matchesType(p, le)) continue;
            double d = distanceToBox(eye, le.method_5829());
            if (d <= reach && d < bestDist) {
                bestDist = d;
                best = le;
            }
        }
        return best;
    }

    /** Wolane z mixina na POCZATKU ClientPlayerEntity.tick() - ZANIM gracz policzy ruch.
     *  Rotacja serwera ustawiana jest tu, zeby tickMovement liczyl sie z jej uzyciem.
     *  Kamera zostaje zapamietana i wraca w postMotion. */
    public void tickRotation(class_310 mc) {
        motionActive = false;
        class_1657 p = mc.field_1724;
        if (!canRun(mc, p)) { target = null; rotating = false; vValid = false; return; }

        if (!(keepTarget.get() && target != null && isValid(mc, p, target))) {
            target = findTarget(mc, p);
        }
        if (target == null || rotMode.is("Off")) { rotating = false; vValid = false; return; }

        class_243 eye = p.method_33571();
        class_243 point = pickPoint(eye, p.method_5828(1.0f), target.method_5829());

        boolean sil = silent.get();
        savedYaw = p.method_36454();            // prawdziwa kamera (to, co widzi gracz)
        savedPitch = p.method_36455();
        float curYaw = (sil && rotating) ? serverYaw : savedYaw;
        float curPitch = (sil && rotating) ? serverPitch : savedPitch;
        prevRotYaw = curYaw;
        prevRotPitch = curPitch;

        // Crity: vanilla nie liczy critu podczas sprintu. Sprint trzeba zdjac PRZED pakietem sprintu
        // (ten idzie na poczatku sendMovementPackets), wiec robimy to tutaj i przywracamy w postMotion.
        sprintCleared = false;
        double critReach = p.method_6057(target) ? range.get() : wallRange.get();
        if (onlyCrits.get() && p.method_5624() && canCrit(p)
                && distanceToBox(eye, target.method_5829()) <= critReach
                && p.method_7261(0.5f) >= minCooldown.get()) {
            p.method_5728(false);
            sprintCleared = true;
        }

        float[] rot;
        if (rotMode.is("Smooth")) {
            if (sil) {
                if (!vValid) { vYaw = savedYaw; vPitch = savedPitch; vValid = true; }
                rot = new float[]{vYaw, vPitch};
            } else {
                rot = new float[]{savedYaw, savedPitch};   // kamera juz wygladzona przez smoothFrame
            }
        } else {
            rot = computeRotation(eye, point, curYaw, curPitch);
        }

        if (sil) {
            serverYaw = snapToGcd(rot[0]);
            serverPitch = snapToGcd(rot[1]);
        } else {
            if (!rotMode.is("Smooth")) {   // Snap: od razu przestaw kamere na cel
                savedYaw = p.method_36454() + class_3532.method_15393(rot[0] - p.method_36454());
                savedPitch = class_3532.method_15363(rot[1], -90f, 90f);
            }
            serverYaw = snapToGcd(savedYaw);
            serverPitch = snapToGcd(savedPitch);
        }

        p.method_36456(serverYaw);           // ruch (tickMovement) policzy sie z tej rotacji
        p.method_36457(serverPitch);
        motionActive = true;
        rotating = true;
    }

    /** Wolane z mixina na POCZATKU sendMovementPackets: tylko utrwalamy rotacje w pakiecie
     *  (gdyby cos w trakcie ticku ruszylo yaw gracza). */
    public void preMotion(class_310 mc) {
        if (!motionActive) return;
        class_1657 p = mc.field_1724;
        if (p == null) return;
        p.method_36456(serverYaw);
        p.method_36457(serverPitch);
    }

    /**
     * Wolane z mixina na KONCU sendMovementPackets: pakiet rotacji juz poszedl do serwera,
     * wiec dopiero teraz wysylamy atak (kolejnosc: look -> attack), a potem przywracamy prawdziwe katy.
     */
    public void postMotion(class_310 mc) {
        class_1657 p = mc.field_1724;
        if (p == null) { motionActive = false; return; }
        try {
            if (isEnabled() && rotating && target != null) tryAttack(mc, p);
        } finally {
            if (sprintCleared) { p.method_5728(true); sprintCleared = false; }
            if (motionActive) {
                p.method_36456(savedYaw);
                p.method_36457(savedPitch);
                p.field_5982 = savedYaw;
                p.field_6004 = savedPitch;
                motionActive = false;
            }
        }
    }

    private boolean canRun(class_310 mc, class_1657 p) {
        if (p == null || mc.field_1687 == null || mc.field_1761 == null) return false;
        if (mc.field_1755 != null || Freecam.isActive() || p.method_7325() || p.method_29504()) return false;
        if (pauseOnUse.get() && p.method_6115()) return false;
        if (onlyWeapon.get()) {
            class_1799 held = p.method_6047();
            if (!held.method_31573(class_3489.field_42611) && !held.method_31573(class_3489.field_42612)) return false;
        }
        return true;
    }

    private void tryAttack(class_310 mc, class_1657 p) {
        class_243 eye = p.method_33571();
        class_238 box = target.method_5829();

        double reach = p.method_6057(target) ? range.get() : wallRange.get();
        if (distanceToBox(eye, box) > reach) return;
        // w Silent sprawdzamy trafienie wzgledem wirtualnej rotacji (serverYaw/Pitch), nie prawdziwej kamery
        if (!lookingAt(p, target, reach)) return;

        // OnlyCrits: bijemy wylacznie, gdy uderzenie na pewno bedzie krytyczne. Sprint jest zdejmowany w preMotion,
        // ale gdyby sie nie udalo (np. cel za sciana), to uderzenie ze sprintem to slaby, niekrytyczny cios - pomijamy.
        if (onlyCrits.get() && (!canCrit(p) || p.method_5624())) return;
        if (target.field_6235 > hurtTimeLimit.get()) return;

        long now = System.currentTimeMillis();
        double minC = Math.min(1.0, minCooldown.get() + ThreadLocalRandom.current().nextDouble() * 0.04);
        if (p.method_7261(0.5f) < minC) return;
        if (now - lastHit < nextDelayMs) return;

        class_1661 inv = p.method_31548();
        int prevSlot = inv.field_7545;
        if (breakShield.get() && target.method_6039()) {
            int axe = findAxeSlot(inv);
            if (axe != -1) inv.field_7545 = axe;
        }

        mc.field_1761.method_2918(p, target);
        p.method_6104(class_1268.field_5808);

        if (swapBack.get() && inv.field_7545 != prevSlot) inv.field_7545 = prevSlot;

        lastHit = now;
        nextDelayMs = computeNextDelay();
    }

    /** Warunki vanillowego critu (poza sprintem, ktory obslugujemy osobno). */
    private static boolean canCrit(class_1657 p) {
        return p.field_6017 > 0.0 && !p.method_24828() && !p.method_6101() && !p.method_5799()
                && !p.method_5765() && !p.method_6059(class_1294.field_5919)
                && p.method_7261(0.5f) > 0.9f;
    }

    // ---------- rotacja modelu gracza (renderer) ----------

    /** Czy model wlasnego gracza ma byc rysowany z rotacja serwera (Silent + aktywny cel). */
    public boolean isRenderRotating() { return isEnabled() && silent.get() && silentModel.get() && rotating; }
    public float renderYaw(float tickDelta) {
        if (rotMode.is("Smooth") && vValid) return vYaw;       // aktualizowane co klatke - plynny model
        return class_3532.method_17821(tickDelta, prevRotYaw, serverYaw);
    }
    public float renderPitch(float tickDelta) {
        if (rotMode.is("Smooth") && vValid) return vPitch;
        return class_3532.method_16439(tickDelta, prevRotPitch, serverPitch);
    }

    private long computeNextDelay() {
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        long extra = jitter.get() > 0 ? rnd.nextInt((int) jitter.get() + 1) : 0;
        return extra;
    }

    /** Liczy docelowa rotacje {yaw, pitch} startujac z (curYaw, curPitch) - Snap od razu, Smooth krokami. */
    private void updateNoise() {
        long ms = System.currentTimeMillis();
        if (ms >= nextNoise) {
            double r = randomness.get();
            ThreadLocalRandom rnd = ThreadLocalRandom.current();
            noiseYaw = (rnd.nextDouble() - 0.5) * 2 * r;
            noisePitch = (rnd.nextDouble() - 0.5) * 2 * r;
            nextNoise = ms + 120 + rnd.nextInt(180);
        }
    }

    private float[] computeRotation(class_243 eye, class_243 point, float curYaw, float curPitch) {
        updateNoise();

        class_243 d = point.method_1020(eye);
        double horiz = Math.sqrt(d.field_1352 * d.field_1352 + d.field_1350 * d.field_1350);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(d.field_1350, d.field_1352)) - 90.0 + noiseYaw);
        float targetPitch = (float) (-Math.toDegrees(Math.atan2(d.field_1351, horiz)) + noisePitch);
        targetPitch = class_3532.method_15363(targetPitch, -90f, 90f);

        float newYaw, newPitch;
        if (rotMode.is("Snap")) {
            // wrapDegrees wzgledem curYaw, zeby kat nie "skakal" o 360 miedzy pakietami
            newYaw = curYaw + class_3532.method_15393(targetYaw - curYaw);
            newPitch = targetPitch;
        } else {
            float dYaw = class_3532.method_15393(targetYaw - curYaw);
            float dPitch = targetPitch - curPitch;
            float rs = (float)(rotSpeed.get() * (0.9 + ThreadLocalRandom.current().nextDouble() * 0.2));
            double factor = 1.0 - Math.exp(-rs * 0.05); // tick = 50 ms
            double step = maxStep.get();
            newYaw = curYaw + (float) class_3532.method_15350(dYaw * factor, -step, step);
            newPitch = curPitch + (float) class_3532.method_15350(dPitch * factor, -step, step);
        }
        newPitch = class_3532.method_15363(newPitch, -90f, 90f);
        return new float[]{newYaw, newPitch};
    }

    // ---------- wybor celu ----------

    private boolean isValid(class_310 mc, class_1657 p, class_1309 le) {
        if (le == p || !le.method_5805() || le.method_7325() || le.method_31481()) return false;
        if (!matchesType(p, le)) return false;

        boolean visible = p.method_6057(le);
        double reach = visible ? range.get() : wallRange.get();
        return distanceToBox(p.method_33571(), le.method_5829()) <= reach;
    }

    private boolean matchesType(class_1657 p, class_1309 le) {
        if (ignoreFriends.get() && Friends.isFriend(le)) return false;
        if (!invisibles.get() && le.method_5767()) return false;
        if (!teammates.get() && le.method_5722(p)) return false;

        if (le instanceof class_1657 pl) {
            if (!players.get()) return false;
            if (!naked.get() && isNaked(pl)) return false;
            return true;
        }
        if (le instanceof class_1569) return hostiles.get();
        if (le instanceof class_1429) return animals.get();
        if (le instanceof class_1308) return others.get();
        return false;
    }

    private static boolean isNaked(class_1657 pl) {
        return pl.method_6118(class_1304.field_6169).method_7960()
                && pl.method_6118(class_1304.field_6174).method_7960()
                && pl.method_6118(class_1304.field_6172).method_7960()
                && pl.method_6118(class_1304.field_6166).method_7960();
    }

    private class_1309 findTarget(class_310 mc, class_1657 p) {
        class_243 eye = p.method_33571();
        class_243 look = p.method_5828(1.0f);
        double halfFov = fov.get() / 2.0;

        class_1309 best = null;
        double bestScore = Double.MAX_VALUE;

        for (class_1297 e : mc.field_1687.method_18112()) {
            if (!(e instanceof class_1309 le) || !isValid(mc, p, le)) continue;

            class_238 box = le.method_5829();
            class_243 center = new class_243((box.field_1323 + box.field_1320) / 2, (box.field_1322 + box.field_1325) / 2, (box.field_1321 + box.field_1324) / 2);
            double angle = angleBetween(look, center.method_1020(eye));
            if (angle > halfFov) continue;

            double score = switch (sort.get()) {
                case "Health" -> le.method_6032() + le.method_6067();
                case "Angle" -> angle;
                case "HurtTime" -> le.field_6235;
                case "Armor" -> le.method_6096();
                default -> distanceToBox(eye, box);
            };
            if (score < bestScore) {
                bestScore = score;
                best = le;
            }
        }
        return best;
    }

    private static int findAxeSlot(class_1661 inv) {
        for (int i = 0; i < 9; i++) {
            if (inv.method_5438(i).method_31573(class_3489.field_42612)) return i;
        }
        return -1;
    }

    // ---------- pomocnicze ----------

    private boolean lookingAt(class_1657 p, class_1309 t, double reach) {
        class_243 eye = p.method_33571();
        class_243 dir = silent.get() && rotating ? p.method_5631(serverPitch, serverYaw) : p.method_5828(1.0f);
        class_243 end = eye.method_1019(dir.method_1021(reach + 0.5));
        class_238 box = t.method_5829().method_1014(0.1);
        return box.method_1006(eye) || box.method_992(eye, end).isPresent();
    }

    private class_243 pickPoint(class_243 eye, class_243 look, class_238 box) {
        double cx = (box.field_1323 + box.field_1320) / 2, cz = (box.field_1321 + box.field_1324) / 2;
        double h = box.field_1325 - box.field_1322;
        switch (aimPoint.get()) {
            case "Head":
                return new class_243(cx, box.field_1322 + h * 0.9, cz);
            case "Closest": {
                double dist = eye.method_1022(new class_243(cx, (box.field_1322 + box.field_1325) / 2, cz));
                class_243 onRay = eye.method_1019(look.method_1021(dist));
                double m = 0.08;
                return new class_243(
                        class_3532.method_15350(onRay.field_1352, box.field_1323 + m, box.field_1320 - m),
                        class_3532.method_15350(onRay.field_1351, box.field_1322 + m, box.field_1325 - m),
                        class_3532.method_15350(onRay.field_1350, box.field_1321 + m, box.field_1324 - m));
            }
            default:
                return new class_243(cx, box.field_1322 + h * 0.65, cz);
        }
    }

    private static double angleBetween(class_243 a, class_243 b) {
        double la = a.method_1033(), lb = b.method_1033();
        if (la == 0 || lb == 0) return 0;
        return Math.toDegrees(Math.acos(class_3532.method_15350(a.method_1026(b) / (la * lb), -1.0, 1.0)));
    }

    /** Krok rotacji vanilli zależny od sensitivity - rotacja serwera musi na nim leżeć. */
    private static float gcdStep() {
        float f = (float)(class_310.method_1551().field_1690.method_42495().method_41753() * 0.6 + 0.2);
        return f * f * f * 1.2f;
    }

    private static float snapToGcd(float angle) {
        float g = gcdStep();
        return g < 1.0E-4f ? angle : angle - (angle % g);
    }

    private static double distanceToBox(class_243 p, class_238 b) {
        double dx = Math.max(Math.max(b.field_1323 - p.field_1352, 0), p.field_1352 - b.field_1320);
        double dy = Math.max(Math.max(b.field_1322 - p.field_1351, 0), p.field_1351 - b.field_1325);
        double dz = Math.max(Math.max(b.field_1321 - p.field_1350, 0), p.field_1350 - b.field_1324);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    // ---------- wizualizacja celu ----------

    private static final int RING_SEGMENTS = 64;

    /**
     * Plynne celowanie jak w AimAssist: rotacja jest przesuwana co KLATKE (nie co tick = 20 razy/s),
     * z wygladzaniem niezaleznym od FPS. Dzieki temu kamera (Silent wylaczony) nie "rwie" -
     * a przy Silent serwer dostaje w kazdym ticku najswiezsza, plynnie dochodzaca rotacje.
     */
    private void smoothFrame(WorldRenderContext ctx, class_310 mc) {
        long now = System.nanoTime();
        double dt = lastFrameNs == 0 ? 0.016 : (now - lastFrameNs) / 1_000_000_000.0;
        lastFrameNs = now;
        dt = Math.min(dt, 0.1);

        class_1657 p = mc.field_1724;
        class_1309 t = target;
        if (!rotating || t == null || !rotMode.is("Smooth") || !canRun(mc, p)) return;
        if (!t.method_5805() || t.method_31481()) return;

        float td = ctx.tickCounter().method_60637(false);
        class_243 eye = p.method_5836(td);
        class_238 box = t.method_5829().method_997(t.method_30950(td).method_1020(t.method_19538()));
        class_243 point = pickPoint(eye, p.method_5828(td), box);

        boolean sil = silent.get();
        if (sil && !vValid) { vYaw = p.method_36454(); vPitch = p.method_36455(); vValid = true; }
        float curYaw = sil ? vYaw : p.method_36454();
        float curPitch = sil ? vPitch : p.method_36455();

        // KLUCZ: jesli promien patrzenia juz trafia w hitbox, przestan krecic -
        // gracz przestalby ruszac mysza, wiec rotacja ma stanac w miejscu.
        class_243 dirNow = p.method_5631(curPitch, curYaw);
        class_243 rayEnd = eye.method_1019(dirNow.method_1021(6.0));
        if (t.method_5829().method_1014(0.05).method_992(eye, rayEnd).isPresent()) {
            return;   // rotacja zostaje stabilna -> serwer widzi "rece"
        }

        updateNoise();
        class_243 d = point.method_1020(eye);
        double horiz = Math.sqrt(d.field_1352 * d.field_1352 + d.field_1350 * d.field_1350);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(d.field_1350, d.field_1352)) - 90.0 + noiseYaw);
        float targetPitch = class_3532.method_15363((float) (-Math.toDegrees(Math.atan2(d.field_1351, horiz)) + noisePitch), -90f, 90f);

                float dYaw = class_3532.method_15393(targetYaw - curYaw);
        float dPitch = targetPitch - curPitch;

        float rs = (float)(rotSpeed.get() * (0.9 + ThreadLocalRandom.current().nextDouble() * 0.2));
        double factor = 1.0 - Math.exp(-rs * dt);
        double step = maxStep.get() * dt * 20.0;
        double moveYaw = class_3532.method_15350(dYaw * factor, -step, step);
        double movePitch = class_3532.method_15350(dPitch * factor, -step, step);

        // szum na DELCIE, nie na kacie
        if (Math.abs(moveYaw) > 0.01)   moveYaw   += (ThreadLocalRandom.current().nextDouble() - 0.5) * 0.15;
        if (Math.abs(movePitch) > 0.01) movePitch += (ThreadLocalRandom.current().nextDouble() - 0.5) * 0.15;

        // kwantyzuj DELTE do siatki GCD
        float g = gcdStep();
        if (g > 1.0E-4f) {
            moveYaw   = Math.round(moveYaw / g) * g;
            movePitch = Math.round(movePitch / g) * g;
        }

        if (Math.abs(moveYaw) < 0.001 && Math.abs(movePitch) < 0.001) return;

        if (sil) {
            vYaw += (float) moveYaw;
            vPitch = class_3532.method_15363(vPitch + (float) movePitch, -90f, 90f);
        } else {
            p.method_5872(moveYaw / 0.15, movePitch / 0.15);
        }
    }

    @Override
    public void onWorldRender(WorldRenderContext ctx, class_310 mc) {
        smoothFrame(ctx, mc);
        if (target == null || !target.method_5805() || targetEsp.is("Off")) return;
        class_4587 ms = ctx.matrixStack();
        if (ms == null) return;
        Matrix4f m = ms.method_23760().method_23761();
        class_243 cam = ctx.camera().method_19326();
        float td = ctx.tickCounter().method_60637(false);

        class_243 lerped = target.method_30950(td);
        int rgb = espColor.rgb();

        if (targetEsp.is("Ring")) {
            renderRing(m, cam, lerped, rgb);
            return;
        }

        class_238 box = target.method_5829().method_997(lerped.method_1020(target.method_19538()));
        if (targetEsp.is("Fill") || targetEsp.is("Both")) {
            class_287 f = RenderUtil.beginFill();
            RenderUtil.fillBox(f, m, cam, box, ((int) fillAlpha.get() << 24) | rgb);
            RenderUtil.endFill(f);
        }
        if (targetEsp.is("Box") || targetEsp.is("Both")) {
            class_287 b = RenderUtil.begin();
            RenderUtil.box(b, m, cam, box, 0xFF000000 | rgb);
            RenderUtil.end(b);
        }
    }

    /**
     * Pierscien jak "scanner": plynnie jedzie po calej wysokosci celu w gore i w dol.
     * Za nim ciagnie sie poswiata - pas, ktorego przezroczystosc spada do zera.
     */
    private void renderRing(Matrix4f m, class_243 cam, class_243 pos, int rgb) {
        double height = target.method_17682();
        double radius = target.method_17681() / 2.0 + 0.2;

        // faza 0..2: 0..1 = w gore, 1..2 = w dol; easing sinusem, zeby zwalnial na koncach
        double period = ringSpeed.get();
        double phase = (System.currentTimeMillis() % (long) (period * 2)) / period;
        boolean up = phase <= 1.0;
        double lin = up ? phase : 2.0 - phase;
        double eased = 0.5 - 0.5 * Math.cos(Math.PI * lin);

        double y = pos.field_1351 + height * eased;
        double trailLen = height * ringTrail.get();
        double yTrail = up ? Math.max(pos.field_1351, y - trailLen) : Math.min(pos.field_1351 + height, y + trailLen);

        int glowA = (int) ringGlow.get();
        int cStrong = (glowA << 24) | rgb;     // poswiata przy pierscieniu
        int cFade = rgb;                       // alpha 0 na koncu ogona
        double half = 0.025;                   // polowa grubosci samego pierscienia
        int cRing = 0xFF000000 | rgb;
        int cRingEdge = 0x00000000 | rgb;

        class_287 b = RenderUtil.beginFill();
        for (int i = 0; i < RING_SEGMENTS; i++) {
            double a1 = Math.PI * 2 * i / RING_SEGMENTS;
            double a2 = Math.PI * 2 * (i + 1) / RING_SEGMENTS;
            float x1 = (float) (pos.field_1352 + Math.cos(a1) * radius - cam.field_1352);
            float z1 = (float) (pos.field_1350 + Math.sin(a1) * radius - cam.field_1350);
            float x2 = (float) (pos.field_1352 + Math.cos(a2) * radius - cam.field_1352);
            float z2 = (float) (pos.field_1350 + Math.sin(a2) * radius - cam.field_1350);

            // ogon / poswiata
            float yr = (float) (y - cam.field_1351), yt = (float) (yTrail - cam.field_1351);
            b.method_22918(m, x1, yr, z1).method_39415(cStrong);
            b.method_22918(m, x2, yr, z2).method_39415(cStrong);
            b.method_22918(m, x2, yt, z2).method_39415(cFade);
            b.method_22918(m, x1, yt, z1).method_39415(cFade);

            // sam pierscien: jasny pas z miekkim brzegiem nad i pod
            float yHi = (float) (y + half - cam.field_1351), yLo = (float) (y - half - cam.field_1351);
            b.method_22918(m, x1, yHi, z1).method_39415(cRing);
            b.method_22918(m, x2, yHi, z2).method_39415(cRing);
            b.method_22918(m, x2, yLo, z2).method_39415(cRing);
            b.method_22918(m, x1, yLo, z1).method_39415(cRing);

            // delikatna otoczka powyzej pierscienia (po stronie przeciwnej do ogona)
            float yEdge = (float) (y + (up ? 1 : -1) * 0.07 - cam.field_1351);
            float yBase = up ? yHi : yLo;
            b.method_22918(m, x1, yBase, z1).method_39415(0x80000000 | rgb);
            b.method_22918(m, x2, yBase, z2).method_39415(0x80000000 | rgb);
            b.method_22918(m, x2, yEdge, z2).method_39415(cRingEdge);
            b.method_22918(m, x1, yEdge, z1).method_39415(cRingEdge);
        }
        RenderUtil.endFill(b);
    }
}
