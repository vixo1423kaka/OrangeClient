package com.example.orangeclient.module.combat;

import com.example.orangeclient.friend.Friends;
import com.example.orangeclient.module.Category;
import com.example.orangeclient.module.Module;
import com.example.orangeclient.module.movement.Freecam;
import com.example.orangeclient.setting.BoolSetting;
import com.example.orangeclient.setting.NumberSetting;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_634;
import net.minecraft.class_640;

/**
 * Trzymasz wedke i klikasz prawym -> haczyk leci w najblizszego gracza.
 *
 * Tuz przed vanillowym rzutem (doItemUse) ustawiamy yaw/pitch tak, zeby tor lotu spławika
 * (grawitacja 0.03, opor 0.92) trafil w PRZEWIDYWANA pozycje celu. Predykcja:
 *  - predkosc celu liczona ze sredniej z ostatnich ticków (a nie z jednego ticku - klient wygladza pozycje),
 *  - ruch w poziomie liniowo, w pionie z grawitacja gracza (skoki / spadanie, z ograniczeniem do podlogi),
 *  - kompensacja pingu + reczny Lead (opoznienie miedzy tym co widzisz a tym co ma serwer),
 *  - trafienie sprawdzane na calym odcinku lotu w tickach (a nie tylko w punktach), z marginesem
 *    jak przy kolizji spławika z encja.
 */
public class AutoRod extends Module {
    /** Maksymalny dystans do celu (w blokach). */
    private final NumberSetting range = add(new NumberSetting("Range", 15, 3, 30, 1));
    private final BoolSetting ignoreFriends = add(new BoolSetting("IgnoreFriends", true));
    /** Celuje tez w graczy, ktorych nie widac (za blokami). */
    private final BoolSetting throughWalls = add(new BoolSetting("ThroughWalls", false));
    /** Wyprzedza ruch celu (poziom + skoki/spadanie). */
    private final BoolSetting predict = add(new BoolSetting("Predict", true));
    /** Dolicza Twoj ping do czasu wyprzedzenia. */
    private final BoolSetting pingComp = add(new BoolSetting("PingComp", true));
    /** Dodatkowe wyprzedzenie w tickach (1 tick = 50 ms) - dostroj, jesli haczyk laduje za/przed celem. */
    private final NumberSetting lead = add(new NumberSetting("Lead", 1, -5, 10, 0.5));
    /** Po rzucie przywraca poprzedni kat patrzenia (kamera sie nie szarpie). */
    private final BoolSetting silent = add(new BoolSetting("Silent", true));

    private static final int HISTORY = 4;          // ile ostatnich pozycji pamietamy (3 odstepy)
    private static final int MAX_TICKS = 100;      // maks. dlugosc symulacji lotu
    private static final double MARGIN = 0.4;      // margines kolizji spławika z encja (0.3 + polowa spławika)

    private final Map<UUID, ArrayDeque<class_243>> history = new HashMap<>();
    private boolean pending;
    private float oldYaw, oldPitch;

    public AutoRod() {
        super("AutoRod", Category.COMBAT);
    }

    @Override
    protected void onEnable() {
        history.clear();
        pending = false;
    }

    @Override
    protected void onDisable() {
        afterUse(class_310.method_1551());
        history.clear();
    }

    /** Zabezpieczenie: jesli z jakiegos powodu nie przywrocilismy katow po rzucie. */
    @Override
    public void onPreTick(class_310 mc) {
        afterUse(mc);
    }

    /** Co tick zapisujemy pozycje graczy, z tego liczymy gladka predkosc. */
    @Override
    public void onTick(class_310 mc) {
        if (mc.field_1687 == null || mc.field_1724 == null) {
            history.clear();
            return;
        }
        Set<UUID> seen = new HashSet<>();
        for (class_1657 e : mc.field_1687.method_18456()) {
            if (e == mc.field_1724) continue;
            UUID id = e.method_5667();
            seen.add(id);
            ArrayDeque<class_243> h = history.computeIfAbsent(id, k -> new ArrayDeque<>());
            class_243 pos = e.method_19538();
            // teleport / respawn - stara historia jest bezuzyteczna
            if (!h.isEmpty() && h.peekLast().method_1025(pos) > 9.0) h.clear();
            h.addLast(pos);
            while (h.size() > HISTORY) h.removeFirst();
        }
        history.keySet().retainAll(seen);
    }

    /** Wolane na poczatku MinecraftClient#doItemUse. */
    public void beforeUse(class_310 mc) {
        class_1657 p = mc.field_1724;
        if (p == null || mc.field_1687 == null || mc.field_1755 != null) return;
        if (Freecam.isActive() || p.method_7325() || !p.method_5805()) return;
        if (!p.method_6047().method_31574(class_1802.field_8378) && !p.method_6079().method_31574(class_1802.field_8378)) return;
        if (p.field_7513 != null) return; // wedka zarzucona - vanilla zwija

        class_1297 target = findTarget(mc, p);
        if (target == null) return;

        float[] rot = solve(mc, p, target);
        if (rot == null) return; // poza zasiegiem rzutu

        oldYaw = p.method_36454();
        oldPitch = p.method_36455();
        pending = silent.get();
        p.method_36456(rot[0]);
        p.method_36457(rot[1]);
    }

    /** Wolane na koncu doItemUse (i co tick jako zabezpieczenie). */
    public void afterUse(class_310 mc) {
        if (!pending) return;
        pending = false;
        class_1657 p = mc != null ? mc.field_1724 : null;
        if (p == null) return;
        p.method_36456(oldYaw);
        p.method_36457(oldPitch);
    }

    private class_1297 findTarget(class_310 mc, class_1657 p) {
        class_1297 best = null;
        double bestDist = range.get();
        for (class_1657 e : mc.field_1687.method_18456()) {
            if (e == p || !e.method_5805() || e.method_7325()) continue;
            if (ignoreFriends.get() && Friends.isFriend(e)) continue;
            if (!throughWalls.get() && !p.method_6057(e)) continue;
            double d = p.method_5739(e);
            if (d > bestDist) continue;
            bestDist = d;
            best = e;
        }
        return best;
    }

    // ------------------------------------------------------------------ predykcja

    /** Predkosc celu (blok/tick) - srednia z historii, awaryjnie roznica z ostatniego ticku. */
    private class_243 velocity(class_1297 e) {
        ArrayDeque<class_243> h = history.get(e.method_5667());
        if (h == null || h.size() < 2) {
            return new class_243(e.method_23317() - e.field_6014, e.method_23318() - e.field_6036, e.method_23321() - e.field_5969);
        }
        return h.peekLast().method_1020(h.peekFirst()).method_1021(1.0 / (h.size() - 1));
    }

    /** Wysokosc podlogi pod celem (do ograniczenia przewidywanego spadania). */
    private static double groundY(class_310 mc, class_1297 e) {
        class_243 from = new class_243(e.method_23317(), e.method_23318() + 0.1, e.method_23321());
        class_243 to = from.method_1031(0, -30, 0);
        class_3965 r = mc.field_1687.method_17742(new class_3959(from, to,
                class_3959.class_3960.field_17558, class_3959.class_242.field_1348, e));
        return r.method_17783() == class_239.class_240.field_1333 ? e.method_23318() - 30 : r.method_17784().field_1351;
    }

    /** Przewidywane polozenie srodka hitboxa celu w tickach 0..n. */
    private class_243[] buildPath(class_310 mc, class_1297 t, int n) {
        class_238 box = t.method_5829();
        class_243 c0 = box.method_1005();
        class_243[] path = new class_243[n + 1];
        path[0] = c0;

        class_243 v = predict.get() ? velocity(t) : class_243.field_1353;
        double hx = v.field_1352, hz = v.field_1350;
        double hl = Math.sqrt(hx * hx + hz * hz);
        if (hl > 1.0) { hx /= hl; hz /= hl; }

        boolean air = predict.get() && !t.method_24828();
        double vy = air ? class_3532.method_15350(v.field_1351, -3.0, 3.0) : 0.0;
        double halfH = (box.field_1325 - box.field_1322) / 2.0;
        double floor = air ? groundY(mc, t) + halfH : c0.field_1351;
        double y = c0.field_1351;

        for (int i = 1; i <= n; i++) {
            if (air) {
                y += vy;
                vy = (vy - 0.08) * 0.98;           // grawitacja gracza
                if (y <= floor) { y = floor; vy = 0; air = false; }
            }
            path[i] = new class_243(c0.field_1352 + hx * i, y, c0.field_1350 + hz * i);
        }
        return path;
    }

    private static class_243 at(class_243[] path, double t) {
        t = class_3532.method_15350(t, 0.0, path.length - 1.001);
        int i = (int) t;
        return path[i].method_35590(path[i + 1], t - i);
    }

    private double leadTicks(class_310 mc, class_1657 p) {
        double l = lead.get();
        if (pingComp.get()) {
            class_634 nh = mc.method_1562();
            class_640 me = nh != null ? nh.method_2871(p.method_5667()) : null;
            if (me != null) l += me.method_2959() / 50.0;
        }
        return Math.max(-5.0, l);
    }

    /** Wylicza {yaw, pitch}, przy ktorych spławik trafi w przewidywana pozycje celu; null, gdy sie nie da. */
    private float[] solve(class_310 mc, class_1657 p, class_1297 t) {
        class_243 eye = p.method_33571();
        double leadT = leadTicks(mc, p);
        class_243[] path = buildPath(mc, t, MAX_TICKS + (int) Math.ceil(Math.max(leadT, 0)) + 3);

        class_238 box = t.method_5829();
        double halfW = (box.field_1320 - box.field_1323) / 2.0;
        double halfH = (box.field_1325 - box.field_1322) / 2.0;

        class_243 aim = at(path, Math.max(leadT, 0));
        float yaw = 0, pitch = 0;
        double[] r = null;
        // iteracje: czas lotu zalezy od pitcha, a punkt wyprzedzenia od czasu lotu
        for (int iter = 0; iter < 4; iter++) {
            class_243 d = aim.method_1020(eye);
            yaw = (float) (Math.toDegrees(Math.atan2(d.field_1350, d.field_1352)) - 90.0);
            r = bestPitch(eye, yaw, path, leadT, halfW, halfH);
            pitch = (float) r[0];
            aim = at(path, r[1] - 0.5 + leadT);
        }
        boolean hit = r[3] > 0.5;
        return (hit || r[2] <= 1.2) ? new float[]{yaw, pitch} : null;
    }

    /**
     * Przeszukuje pitche i symuluje lot spławika. Trafienie = odcinek lotu w danym ticku przecina
     * hitbox celu (powiekszony o margines). Zwraca {pitch, tick, dystansDoSrodka, trafil(0/1)}.
     */
    private static double[] bestPitch(class_243 eye, float yaw, class_243[] path, double leadT, double halfW, double halfH) {
        double yr = Math.toRadians(yaw);
        double fx = -Math.sin(yr), fz = Math.cos(yr);
        double ew = 2 * (halfW + MARGIN), eh = 2 * (halfH + MARGIN);

        double bestPitch = 0, bestTick = 1, bestDist = Double.MAX_VALUE;
        boolean bestHit = false;

        for (double pitch = -89; pitch <= 89; pitch += 0.25) {
            double pr = Math.toRadians(pitch);
            // predkosc startowa jak w konstruktorze FishingBobberEntity
            double hs = 0.6 * Math.cos(pr) + 0.5;
            double vx = fx * hs, vy = -Math.tan(pr) * hs, vz = fz * hs;
            double x = eye.field_1352 + fx * 0.3, y = eye.field_1351, z = eye.field_1350 + fz * 0.3;

            for (int tick = 1; tick <= MAX_TICKS; tick++) {
                class_243 prev = new class_243(x, y, z);
                vy -= 0.03;
                x += vx; y += vy; z += vz;
                vx *= 0.92; vy *= 0.92; vz *= 0.92;
                class_243 cur = new class_243(x, y, z);

                class_243 c = at(path, tick - 0.5 + leadT);
                class_238 b = class_238.method_30048(c, ew, eh, ew);
                boolean hit = b.method_1006(prev) || b.method_1006(cur) || b.method_992(prev, cur).isPresent();
                double dist = pointSegmentDist(c, prev, cur);

                if (hit ? (!bestHit || dist < bestDist) : (!bestHit && dist < bestDist)) {
                    bestHit = hit;
                    bestDist = dist;
                    bestPitch = pitch;
                    bestTick = tick;
                }
                if (y < eye.field_1351 - 80) break;
            }
        }
        return new double[]{bestPitch, bestTick, bestDist, bestHit ? 1 : 0};
    }

    private static double pointSegmentDist(class_243 p, class_243 a, class_243 b) {
        class_243 ab = b.method_1020(a);
        double len2 = ab.method_1027();
        double t = len2 == 0 ? 0 : class_3532.method_15350(p.method_1020(a).method_1026(ab) / len2, 0.0, 1.0);
        return p.method_1022(a.method_1019(ab.method_1021(t)));
    }
}
