package com.example.orangeclient.module.combat;

import com.example.orangeclient.friend.Friends;
import com.example.orangeclient.module.Category;
import com.example.orangeclient.module.Module;
import com.example.orangeclient.module.movement.Freecam;
import com.example.orangeclient.setting.BoolSetting;
import com.example.orangeclient.setting.NumberSetting;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3489;
import net.minecraft.class_3966;

/** Bije automatycznie, gdy celownik jest na przeciwniku. Odstep miedzy uderzeniami ustawiasz w opcjach. */
public class TriggerBot extends Module {
    /** Minimalny odstep miedzy uderzeniami w milisekundach (dokladnosc ~50 ms, bo sprawdzamy co tick). */
    private final NumberSetting delay = add(new NumberSetting("Delay", 100, 0, 1000, 10));
    /** Losowe dodatkowe opoznienie 0..Jitter ms przy kazdym uderzeniu (zeby nie bylo idealnie rowno). */
    private final NumberSetting jitter = add(new NumberSetting("Jitter", 50, 0, 300, 10));
    /** Czeka az naladuje sie cooldown ataku (pelna sila uderzenia, jak w 1.9+). */
    private final BoolSetting waitCooldown = add(new BoolSetting("WaitCooldown", true));
    private final NumberSetting cooldownMin = add(new NumberSetting("MinCooldown", 0.9, 0.1, 1.0, 0.05));
    private final BoolSetting onlyPlayers = add(new BoolSetting("OnlyPlayers", true));
    private final BoolSetting ignoreFriends = add(new BoolSetting("IgnoreFriends", true));
    /** Bije tylko, gdy uderzenie bedzie krytyczne (spadasz, nie sprintujesz, cooldown >= 0.9). */
    private final BoolSetting crits = add(new BoolSetting("OnlyCrits", false));
    /** Bije tylko mieczem / toporem w rece. */
    private final BoolSetting onlyWeapon = add(new BoolSetting("OnlyWeapon", false));
    /** Bije tez wtedy, gdy miedzy Toba a celem jest blok (celownik "widzi" encje przez sciane). */
    private final BoolSetting throughWalls = add(new BoolSetting("ThroughWalls", false));

    private long lastHit;
    private long nextDelayMs;

    public TriggerBot() {
        super("TriggerBot", Category.COMBAT);
    }

    @Override
    protected void onEnable() {
        lastHit = 0;
        nextDelayMs = 0;
    }

    @Override
    public void onTick(class_310 mc) {
        class_1657 p = mc.field_1724;
        if (p == null || mc.field_1687 == null || mc.field_1761 == null) return;
        if (mc.field_1755 != null || Freecam.isActive() || p.method_6115()) return;

        class_1297 target = null;
        class_239 hr = mc.field_1765;
        if (hr instanceof class_3966 ehr && hr.method_17783() == class_239.class_240.field_1331) {
            target = ehr.method_17782();
        } else if (throughWalls.get()) {
            target = raycastEntityIgnoringBlocks(mc, p);
        }
        if (target == null) return;
        if (!(target instanceof class_1309 le) || !le.method_5805()) return;
        if (onlyPlayers.get() && !(target instanceof class_1657)) return;
        if (ignoreFriends.get() && Friends.isFriend(target)) return;

        if (onlyWeapon.get()) {
            class_1799 held = p.method_6047();
            if (!held.method_31573(class_3489.field_42611) && !held.method_31573(class_3489.field_42612)) return;
        }
        if (crits.get() && !(p.field_6017 > 0.0 && !p.method_24828() && !p.method_6101()
                && !p.method_5799() && !p.method_5765() && !p.method_5624()
                && !p.method_6059(class_1294.field_5919)
                && p.method_7261(0.5f) > 0.9f)) return;
        double minC = Math.min(1.0, cooldownMin.get() + ThreadLocalRandom.current().nextDouble() * 0.04);
        if (waitCooldown.get() && p.method_7261(0.5f) < minC) return;

        long now = System.currentTimeMillis();
        if (now - lastHit < delay.get() + nextDelayMs) return;

        mc.field_1761.method_2918(p, target);
        p.method_6104(class_1268.field_5808);
        lastHit = now;
        int j = (int) jitter.get();
        nextDelayMs = j > 0 ? ThreadLocalRandom.current().nextInt(j + 1) : 0;
    }

    /** Najblizsza encja na linii patrzenia w zasiegu ataku - bloki sie nie licza. */
    private static class_1297 raycastEntityIgnoringBlocks(class_310 mc, class_1657 p) {
        double reach = p.method_55755();
        class_243 eye = p.method_33571();
        class_243 end = eye.method_1019(p.method_5828(1.0f).method_1021(reach));
        class_238 search = p.method_5829().method_18804(p.method_5828(1.0f).method_1021(reach)).method_1014(1.0);

        class_1297 best = null;
        double bestDist = reach * reach;
        for (class_1297 e : mc.field_1687.method_8333(p, search, x -> !x.method_7325() && x.method_5863())) {
            class_243 hit = e.method_5829().method_992(eye, end).orElse(null);
            if (hit == null) continue;
            double d = eye.method_1025(hit);
            if (d < bestDist) {
                bestDist = d;
                best = e;
            }
        }
        return best;
    }
}
