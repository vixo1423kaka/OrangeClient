package com.example.orangeclient.module.combat;

import com.example.orangeclient.friend.Friends;
import com.example.orangeclient.module.Category;
import com.example.orangeclient.module.Module;
import com.example.orangeclient.module.ModuleManager;
import com.example.orangeclient.setting.BoolSetting;
import com.example.orangeclient.setting.NumberSetting;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3966;

/**
 * Powieksza hitboxy encji w celowniku (z kazdej strony o maks. Size bloku), wiec latwiej w nie trafic.
 *
 * Dlaczego poprzednia wersja nie dzialala na serwerach:
 *  - nadpisywala getTargetingMargin dla KAZDEGO trafienia, wiec zawsze uzywala pelnego Size
 *    (np. 0.3) - serwerowy anticheat widzi, ze promien patrzenia nie trafia w prawdziwy hitbox;
 *  - nie pilnowala, zeby prawdziwy hitbox byl w zasiegu (serwer liczy dystans do prawdziwego boxa);
 *  - psula tez kolizje pociskow po stronie klienta (getTargetingMargin uzywa ProjectileUtil).
 *
 * Teraz: vanilla trafienie zawsze ma pierwszenstwo, a gdy go brak, uzywamy NAJMNIEJSZEGO marginesu
 * (0..Size), przy ktorym promien trafia, i tylko jesli prawdziwy hitbox jest w zasiegu.
 */
public class Hitbox extends Module {
    /** Maksymalny margines w blokach z kazdej strony (vanilla = 0). */
    private final NumberSetting size = add(new NumberSetting("Size", 0.1, 0.0, 1.0, 0.01));
    /** Uzywa najmniejszego marginesu, przy ktorym trafiasz (zamiast zawsze pelnego Size). */
    private final BoolSetting adaptive = add(new BoolSetting("Adaptive", true));
    private final BoolSetting onlyPlayers = add(new BoolSetting("OnlyPlayers", true));
    private final BoolSetting ignoreFriends = add(new BoolSetting("IgnoreFriends", true));

    public Hitbox() {
        super("Hitbox", Category.COMBAT);
    }

    /** Maksymalny margines dla danej encji (0, gdy modul nie dotyczy tej encji). */
    public static float extra(class_1297 e) {
        Hitbox m = ModuleManager.get(Hitbox.class);
        if (m == null || !m.isEnabled()) return 0f;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || e == mc.field_1724 || !(e instanceof class_1309)) return 0f;
        if (m.onlyPlayers.get() && !(e instanceof class_1657)) return 0f;
        if (m.ignoreFriends.get() && Friends.isFriend(e)) return 0f;
        return (float) m.size.get();
    }

    /**
     * Wywolywane z GameRenderer.findCrosshairTarget (na RETURN). Zwraca vanillowy wynik,
     * a gdy nie trafiono w encje - probuje trafic powiekszonym hitboxem.
     */
    public static class_239 adjust(class_239 vanilla, class_1297 camera, double blockRange, double entityRange, float tickDelta) {
        Hitbox m = ModuleManager.get(Hitbox.class);
        if (m == null || !m.isEnabled()) return vanilla;
        if (vanilla != null && vanilla.method_17783() == class_239.class_240.field_1331) return vanilla;

        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || mc.field_1724 == null || camera == null) return vanilla;
        double maxMargin = m.size.get();
        if (maxMargin <= 0.0) return vanilla;

        class_243 eye = camera.method_5836(tickDelta);
        class_243 dir = camera.method_5828(tickDelta);

        // promien jest odrobine dluzszy niz zasieg - powiekszony box moze byc trafiony dalej niz prawdziwy
        double limit = entityRange + maxMargin;
        // blok przed encja nadal ja zaslania
        if (vanilla != null && vanilla.method_17783() == class_239.class_240.field_1332) {
            limit = Math.min(limit, vanilla.method_17784().method_1022(eye));
        }
        class_243 end = eye.method_1019(dir.method_1021(limit));
        class_238 search = camera.method_5829().method_18804(dir.method_1021(limit)).method_1014(1.0 + maxMargin);

        class_1297 best = null;
        class_243 bestPos = null;
        double bestDist = limit * limit;

        for (class_1297 e : mc.field_1687.method_8333(camera, search, x -> !x.method_7325() && x.method_5863())) {
            if (extra(e) <= 0f) continue;
            class_238 real = e.method_5829();
            // serwer liczy zasieg do PRAWDZIWEGO hitboxa - nie wychodzimy poza niego
            if (distanceToBox(eye, real) > entityRange) continue;

            double margin = m.adaptive.get() ? minimalMargin(real, eye, end, maxMargin) : maxMargin;
            if (margin < 0.0) continue;
            class_243 hit = real.method_1014(margin).method_992(eye, end).orElse(null);
            if (hit == null) continue;

            double d = eye.method_1025(hit);
            if (d < bestDist) {
                bestDist = d;
                best = e;
                bestPos = hit;
            }
        }
        return best == null ? vanilla : new class_3966(best, bestPos);
    }

    /** Najmniejszy margines z zakresu (0, max], przy ktorym promien trafia w box; -1 gdy nawet max nie trafia. */
    private static double minimalMargin(class_238 real, class_243 from, class_243 to, double max) {
        if (real.method_1014(max).method_992(from, to).isEmpty()) return -1.0;
        double lo = 0.0, hi = max;
        for (int i = 0; i < 10; i++) {
            double mid = (lo + hi) * 0.5;
            if (real.method_1014(mid).method_992(from, to).isPresent()) hi = mid; else lo = mid;
        }
        return hi;
    }

    private static double distanceToBox(class_243 p, class_238 b) {
        double dx = Math.max(Math.max(b.field_1323 - p.field_1352, 0), p.field_1352 - b.field_1320);
        double dy = Math.max(Math.max(b.field_1322 - p.field_1351, 0), p.field_1351 - b.field_1325);
        double dz = Math.max(Math.max(b.field_1321 - p.field_1350, 0), p.field_1350 - b.field_1324);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }
}
