package com.example.orangeclient.module.combat;

import com.example.orangeclient.friend.Friends;
import com.example.orangeclient.module.Category;
import com.example.orangeclient.module.Module;
import com.example.orangeclient.module.movement.Freecam;
import com.example.orangeclient.setting.BoolSetting;
import com.example.orangeclient.setting.ModeSetting;
import com.example.orangeclient.setting.NumberSetting;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3489;
import net.minecraft.class_3532;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Plynnie dociaga celownik do najblizszego (katowo) przeciwnika w zasiegu i polu widzenia.
 * Dziala co klatke, wiec ruch jest gladki; nie wysyla zadnych dodatkowych pakietow -
 * serwer widzi zwykly ruch kamery.
 */
public class AimAssist extends Module {
    /** Maksymalny dystans do hitboxa celu (w blokach). */
    private final NumberSetting range = add(new NumberSetting("Range", 4.5, 1.0, 8.0, 0.1));
    /** Calkowity kat widzenia (stopnie) - cel musi byc w tym stozku wokol celownika. */
    private final NumberSetting fov = add(new NumberSetting("FOV", 70, 10, 180, 5));
    /** Sila przyciagania (im wiecej, tym szybciej celownik dochodzi do celu). */
    private final NumberSetting speed = add(new NumberSetting("Speed", 6, 1, 30, 0.5));
    /** Maks. obrot na jedna klatke w stopniach - ogranicza gwaltowne szarpniecia. */
    private final NumberSetting maxStep = add(new NumberSetting("MaxStep", 8, 1, 40, 0.5));
    /** Losowe odchylenie punktu celowania (w stopniach), zeby ruch nie byl idealny. */
    private final NumberSetting randomness = add(new NumberSetting("Randomness", 0.4, 0, 3, 0.1));
    /** Jaki punkt hitboxa wybieramy. */
    private final ModeSetting aimPoint = add(new ModeSetting("AimPoint", "Closest", "Closest", "Chest", "Head"));
    private final BoolSetting onlyWeapon = add(new BoolSetting("OnlyWeapon", false));
    private final BoolSetting onlyPlayers = add(new BoolSetting("OnlyPlayers", true));
    private final BoolSetting ignoreFriends = add(new BoolSetting("IgnoreFriends", true));
    private final BoolSetting throughWalls = add(new BoolSetting("ThroughWalls", false));

    private long lastFrame;
    /** Pozioma/pionowa losowa poprawka, odswiezana co jakis czas (a nie co klatke - bez drgan). */
    private double noiseYaw, noisePitch;
    private long nextNoise;

    public AimAssist() {
        super("AimAssist", Category.COMBAT);
    }

    @Override
    protected void onEnable() {
        lastFrame = 0;
    }

    @Override
    public void onWorldRender(WorldRenderContext ctx, class_310 mc) {
        long now = System.nanoTime();
        double dt = lastFrame == 0 ? 0.016 : (now - lastFrame) / 1_000_000_000.0;
        lastFrame = now;
        dt = Math.min(dt, 0.1);

        class_1657 p = mc.field_1724;
        if (p == null || mc.field_1687 == null || mc.field_1755 != null) return;
        if (Freecam.isActive() || p.method_6115() || p.method_7325() || p.method_29504()) return;
        if (onlyWeapon.get()) {
            class_1799 held = p.method_6047();
            if (!held.method_31573(class_3489.field_42611) && !held.method_31573(class_3489.field_42612)) return;
        }

        class_243 eye = p.method_33571();
        class_243 look = p.method_5828(1.0f);
        double halfFov = fov.get() / 2.0;

        class_243 bestPoint = null;
        double bestAngle = Double.MAX_VALUE;

        for (class_1297 e : mc.field_1687.method_18112()) {
            if (e == p || !(e instanceof class_1309 le) || !le.method_5805() || le.method_7325()) continue;
            if (onlyPlayers.get() && !(e instanceof class_1657)) continue;
            if (ignoreFriends.get() && Friends.isFriend(e)) continue;
            if (!throughWalls.get() && !p.method_6057(e)) continue;

            class_238 box = e.method_5829();
            if (distanceToBox(eye, box) > range.get()) continue;

            class_243 point = pickPoint(eye, look, box);
            double angle = angleBetween(look, point.method_1020(eye));
            if (angle > halfFov || angle >= bestAngle) continue;
            bestAngle = angle;
            bestPoint = point;
        }
        if (bestPoint == null) return;

        // losowa poprawka zmienia sie co 120-300 ms
        long ms = now / 1_000_000L;
        if (ms >= nextNoise) {
            double r = randomness.get();
            ThreadLocalRandom rnd = ThreadLocalRandom.current();
            noiseYaw = (rnd.nextDouble() - 0.5) * 2 * r;
            noisePitch = (rnd.nextDouble() - 0.5) * 2 * r;
            nextNoise = ms + 120 + rnd.nextInt(180);
        }

        class_243 d = bestPoint.method_1020(eye);
        double horiz = Math.sqrt(d.field_1352 * d.field_1352 + d.field_1350 * d.field_1350);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(d.field_1350, d.field_1352)) - 90.0 + noiseYaw);
        float targetPitch = (float) (-Math.toDegrees(Math.atan2(d.field_1351, horiz)) + noisePitch);

        float dYaw = class_3532.method_15393(targetYaw - p.method_36454());
        float dPitch = targetPitch - p.method_36455();

        // wygladzanie niezalezne od FPS: ulamek drogi pokonywany w tej klatce
        double factor = 1.0 - Math.exp(-speed.get() * dt);
        double step = maxStep.get();
        double moveYaw = class_3532.method_15350(dYaw * factor, -step, step);
        double movePitch = class_3532.method_15350(dPitch * factor, -step, step);
        if (Math.abs(moveYaw) < 0.001 && Math.abs(movePitch) < 0.001) return;

        // changeLookDirection mnozy przez 0.15 (jak ruch myszy) i poprawia poprzednie katy (brak drgan kamery)
        p.method_5872(moveYaw / 0.15, movePitch / 0.15);
    }

    /** Punkt hitboxa, do ktorego celujemy. */
    private class_243 pickPoint(class_243 eye, class_243 look, class_238 box) {
        double cx = (box.field_1323 + box.field_1320) / 2, cz = (box.field_1321 + box.field_1324) / 2;
        double h = box.field_1325 - box.field_1322;
        switch (aimPoint.get()) {
            case "Head":
                return new class_243(cx, box.field_1322 + h * 0.9, cz);
            case "Chest":
                return new class_243(cx, box.field_1322 + h * 0.65, cz);
            default: {
                // najblizszy punkt hitboxa wzgledem aktualnego kierunku patrzenia - najmniejszy ruch
                double dist = eye.method_1022(new class_243(cx, (box.field_1322 + box.field_1325) / 2, cz));
                class_243 onRay = eye.method_1019(look.method_1021(dist));
                double m = 0.08; // maly margines od krawedzi, zeby nie celowac w sam brzeg
                return new class_243(
                        class_3532.method_15350(onRay.field_1352, box.field_1323 + m, box.field_1320 - m),
                        class_3532.method_15350(onRay.field_1351, box.field_1322 + m, box.field_1325 - m),
                        class_3532.method_15350(onRay.field_1350, box.field_1321 + m, box.field_1324 - m));
            }
        }
    }

    private static double angleBetween(class_243 a, class_243 b) {
        double la = a.method_1033(), lb = b.method_1033();
        if (la == 0 || lb == 0) return 0;
        return Math.toDegrees(Math.acos(class_3532.method_15350(a.method_1026(b) / (la * lb), -1.0, 1.0)));
    }

    private static double distanceToBox(class_243 p, class_238 b) {
        double dx = Math.max(Math.max(b.field_1323 - p.field_1352, 0), p.field_1352 - b.field_1320);
        double dy = Math.max(Math.max(b.field_1322 - p.field_1351, 0), p.field_1351 - b.field_1325);
        double dz = Math.max(Math.max(b.field_1321 - p.field_1350, 0), p.field_1350 - b.field_1324);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }
}
