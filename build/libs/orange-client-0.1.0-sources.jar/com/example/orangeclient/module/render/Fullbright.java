package com.example.orangeclient.module.render;

import com.example.orangeclient.module.Category;
import com.example.orangeclient.module.Module;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_310;

public class Fullbright extends Module {
    public Fullbright() {
        super("Fullbright", Category.RENDER);
    }

    @Override
    public void onTick(class_310 mc) {
        if (mc.field_1724 == null) return;
        class_1293 cur = mc.field_1724.method_6112(class_1294.field_5925);
        if (cur == null || cur.method_5584() < 240) {
            // efekt tylko po stronie klienta, serwer o nim nie wie
            mc.field_1724.method_6092(new class_1293(class_1294.field_5925, 1000, 0, false, false, false));
        }
    }

    @Override
    protected void onDisable() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null) mc.field_1724.method_6016(class_1294.field_5925);
    }
}
