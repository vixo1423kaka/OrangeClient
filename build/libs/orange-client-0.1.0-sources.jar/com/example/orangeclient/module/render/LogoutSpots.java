package com.example.orangeclient.module.render;

import com.example.orangeclient.friend.Friends;
import com.example.orangeclient.module.Category;
import com.example.orangeclient.module.Module;
import com.example.orangeclient.setting.BoolSetting;
import com.example.orangeclient.setting.ColorSetting;
import com.example.orangeclient.setting.NumberSetting;
import com.example.orangeclient.util.RenderUtil;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1684;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_5321;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_746;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Pokazuje miejsca, w ktorych gracz NAGLE zniknal ci z pola widzenia (np. wylogowal sie):
 * polprzezroczysty box (jak ESP) z nickiem nad nim. Punkt zostaje do wyjscia z serwera.
 *
 * Punkt powstaje, gdy gracz, ktorego widziales, znika ze swiata, ale NIE gdy:
 *  - rzucil perle Endu (zanim punkt powstanie, sprawdzamy, czy ten gracz nie rzucil perly - to byl teleport),
 *  - zginal (encja znika po animacji smierci),
 *  - byl daleko (MaxDistance) - wtedy po prostu wyszedl poza zasieg renderowania,
 *  - zniknal razem z calym swiatem (zmiana wymiaru, respawn).
 * Punkty sa przypisane do wymiaru, w ktorym gracz zniknal.
 */
public class LogoutSpots extends Module {
    private final NumberSetting range = add(new NumberSetting("Range", 512, 32, 2048, 32));
    /** Zniknal z odleglosci wiekszej niz to = wyszedl poza zasieg renderu, a nie "zniknal nagle". */
    private final NumberSetting maxDistance = add(new NumberSetting("MaxDistance", 40, 8, 128, 4));
    /** Jak dlugo po zobaczeniu rzuconej perly uznajemy zniknieciegracza za teleport (sekundy). */
    private final NumberSetting pearlWindow = add(new NumberSetting("PearlWindow", 12, 2, 60, 1));
    private final NumberSetting fillAlpha = add(new NumberSetting("FillAlpha", 70, 0, 200, 5));
    private final NumberSetting scale = add(new NumberSetting("Scale", 1.0, 0.5, 3.0, 0.1));
    private final BoolSetting distance = add(new BoolSetting("Distance", true));
    private final ColorSetting color = add(new ColorSetting("Color", 0xFF7A00, true));
    private final ColorSetting friendColor = add(new ColorSetting("Friend Color", 0x55FFFF, true));

    /** Stan gracza z poprzedniego ticku (zeby wiedziec, gdzie byl, zanim zniknal). */
    private record Seen(String name, class_238 box, double dist, boolean dead, class_5321<class_1937> dim) { }

    private record Spot(UUID id, String name, class_238 box, boolean friend, class_5321<class_1937> dim) { }

    private record Label(String text, int rgb, float x, float y) { }

    private final Map<UUID, Seen> seen = new HashMap<>();
    private final Map<UUID, Long> pearlTick = new HashMap<>();   // gracz -> tick, w ktorym widzielismy jego perle
    private final List<Spot> spots = new ArrayList<>();
    private final List<Label> labels = new ArrayList<>();
    private class_634 lastHandler;
    private class_638 lastWorld;
    private class_746 lastPlayer;
    private long tickCount;

    public LogoutSpots() {
        super("LogoutSpots", Category.RENDER);
    }

    @Override
    protected void onEnable() {
        // wlaczenie w trakcie gry: sledzenie od nowa, ale zapisane punkty zostaja
        seen.clear();
        pearlTick.clear();
    }

    @Override
    protected void onDisable() { labels.clear(); }

    /** Wyjscie z serwera / wejscie na inny: kasujemy wszystko. */
    private void resetAll() {
        seen.clear();
        pearlTick.clear();
        spots.clear();
        labels.clear();
    }

    @Override
    public void onTick(class_310 mc) {
        class_634 nh = mc.method_1562();
        if (nh != lastHandler) {          // inny serwer albo wyjscie z serwera (zmiana wymiaru NIE zmienia handlera)
            resetAll();
            lastHandler = nh;
        }
        if (mc.field_1687 == null || mc.field_1724 == null || nh == null) return;
        tickCount++;

        // zmiana wymiaru / respawn: encje znikaja hurtowo - to nie sa wylogowania
        if (mc.field_1687 != lastWorld || mc.field_1724 != lastPlayer) {
            seen.clear();
            pearlTick.clear();
            lastWorld = mc.field_1687;
            lastPlayer = mc.field_1724;
        }

        // 1) perly Endu: zapisujemy, kto rzucil perle (jej wlasciciel)
        for (class_1297 e : mc.field_1687.method_18112()) {
            if (!(e instanceof class_1684 pearl)) continue;
            UUID owner = null;
            class_1297 o = pearl.method_24921();
            if (o != null) {
                owner = o.method_5667();
            } else {                                   // awaryjnie: najblizszy gracz przy perle
                double best = 6.0;
                for (class_1657 p : mc.field_1687.method_18456()) {
                    double d = p.method_19538().method_1022(pearl.method_19538());
                    if (d < best) {
                        best = d;
                        owner = p.method_5667();
                    }
                }
            }
            if (owner != null) pearlTick.put(owner, tickCount);
        }

        // 2) gracze widoczni teraz (kogo mamy w zasiegu renderu)
        class_5321<class_1937> dim = mc.field_1687.method_27983();
        class_243 me = mc.field_1724.method_19538();
        Map<UUID, Seen> current = new HashMap<>();
        for (class_1657 p : mc.field_1687.method_18456()) {
            if (p == mc.field_1724) continue;
            UUID id = p.method_5667();
            boolean dead = p.method_29504() || p.method_6032() <= 0f;
            current.put(id, new Seen(p.method_5477().getString(), p.method_5829(), me.method_1022(p.method_19538()), dead, dim));
            spots.removeIf(sp -> sp.id().equals(id));  // wrocil w pole widzenia - stary punkt niepotrzebny
        }

        // 3) kto byl w poprzednim ticku, a teraz go nie ma = nagle zniknal
        long pearlTicks = (long) (pearlWindow.get() * 20);
        for (Map.Entry<UUID, Seen> en : seen.entrySet()) {
            UUID id = en.getKey();
            if (current.containsKey(id)) continue;
            Seen s = en.getValue();

            if (s.dead()) continue;                                    // zginal
            if (s.dist() > maxDistance.get()) continue;                // wyszedl poza zasieg renderu
            Long pt = pearlTick.get(id);
            if (pt != null && tickCount - pt <= pearlTicks) continue;  // rzucil perle - to teleport, nie wylogowanie

            spots.removeIf(sp -> sp.id().equals(id));
            spots.add(new Spot(id, s.name(), s.box(), Friends.isFriend(s.name()), s.dim()));
        }
        seen.clear();
        seen.putAll(current);

        pearlTick.values().removeIf(t -> tickCount - t > 20L * 120);   // porzadki
    }

    /** Faza swiata: wypelnione boxy + obrys, a pozycje napisow rzutujemy na ekran. */
    @Override
    public void onWorldRender(WorldRenderContext ctx, class_310 mc) {
        labels.clear();
        if (spots.isEmpty()) return;
        class_4587 ms = ctx.matrixStack();
        if (ms == null) return;
        Matrix4f m = ms.method_23760().method_23761();

        class_4184 camera = ctx.camera();
        class_243 cam = camera.method_19326();
        Matrix4f view = new Matrix4f().rotation(camera.method_23767().conjugate(new Quaternionf()));
        Matrix4f mvp = new Matrix4f(ctx.projectionMatrix()).mul(view);
        int sw = mc.method_22683().method_4486();
        int sh = mc.method_22683().method_4502();

        int alpha = Math.max(0, Math.min(255, (int) fillAlpha.get()));
        class_243 me = mc.field_1724.method_19538();

        List<Spot> vis = new ArrayList<>();
        List<Double> dists = new ArrayList<>();
        class_5321<class_1937> dim = mc.field_1687.method_27983();
        for (Spot sp : spots) {
            if (!sp.dim().equals(dim)) continue;                       // punkt z innego wymiaru
            double d = me.method_1022(sp.box().method_1005());
            if (d > range.get()) continue;
            vis.add(sp);
            dists.add(d);
        }
        if (vis.isEmpty()) return;

        class_287 fill = RenderUtil.beginFill();
        for (Spot sp : vis) {
            int rgb = sp.friend() ? friendColor.rgb() : color.rgb();
            RenderUtil.fillBox(fill, m, cam, sp.box(), (alpha << 24) | rgb);
        }
        RenderUtil.endFill(fill);

        class_287 lines = RenderUtil.begin();
        for (Spot sp : vis) {
            int rgb = sp.friend() ? friendColor.rgb() : color.rgb();
            RenderUtil.box(lines, m, cam, sp.box(), 0xFF000000 | rgb);
        }
        RenderUtil.end(lines);

        for (int i = 0; i < vis.size(); i++) {
            Spot sp = vis.get(i);
            class_238 b = sp.box();
            class_243 rel = new class_243((b.field_1323 + b.field_1320) / 2, b.field_1325 + 0.3, (b.field_1321 + b.field_1324) / 2).method_1020(cam);
            Vector4f v = new Vector4f((float) rel.field_1352, (float) rel.field_1351, (float) rel.field_1350, 1f);
            mvp.transform(v);
            if (v.w <= 0.01f) continue;                       // za plecami
            float nx = v.x / v.w, ny = v.y / v.w;
            if (nx < -1.5f || nx > 1.5f || ny < -1.5f || ny > 1.5f) continue;

            String text = sp.name() + (distance.get() ? " " + (int) Math.round(dists.get(i)) + "m" : "");
            int rgb = sp.friend() ? friendColor.rgb() : color.rgb();
            labels.add(new Label(text, rgb, (nx * 0.5f + 0.5f) * sw, (0.5f - ny * 0.5f) * sh));
        }
    }

    /** Faza HUD: nick nad boxem. */
    @Override
    public void onHudRender(class_332 ctx, class_310 mc) {
        if (labels.isEmpty()) return;
        List<Label> copy = new ArrayList<>(labels);
        labels.clear();

        class_327 tr = mc.field_1772;
        class_4587 ms = ctx.method_51448();
        float s = (float) scale.get();
        for (Label l : copy) {
            int w = tr.method_1727(l.text());
            ms.method_22903();
            ms.method_46416(l.x(), l.y(), 0);
            ms.method_22905(s, s, 1f);
            ctx.method_25294(-w / 2 - 2, -11, w / 2 + 2, 0, 0x90000000);
            ctx.method_25303(tr, l.text(), -w / 2, -9, 0xFF000000 | l.rgb());
            ms.method_22909();
        }
    }
}
