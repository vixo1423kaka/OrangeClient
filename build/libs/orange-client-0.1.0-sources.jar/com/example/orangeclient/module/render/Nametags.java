package com.example.orangeclient.module.render;

import com.example.orangeclient.module.Category;
import com.example.orangeclient.module.Module;
import com.example.orangeclient.setting.BoolSetting;
import com.example.orangeclient.setting.NumberSetting;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_124;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_5250;
import net.minecraft.class_640;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class Nametags extends Module {
    private final BoolSetting nick = add(new BoolSetting("Nick", true));
    private final BoolSetting ping = add(new BoolSetting("Ping", true));
    private final BoolSetting health = add(new BoolSetting("Health", true));
    private final BoolSetting armor = add(new BoolSetting("Armor", true));
    private final BoolSetting mainHand = add(new BoolSetting("MainHand", true));
    private final BoolSetting offHand = add(new BoolSetting("OffHand", true));
    private final BoolSetting enchants = add(new BoolSetting("Enchants", true));
    private final BoolSetting hideVanilla = add(new BoolSetting("HideVanilla", true));
    private final NumberSetting scale = add(new NumberSetting("Scale", 1.0, 0.5, 3.0, 0.1));
    private final NumberSetting range = add(new NumberSetting("Range", 128, 16, 256, 16));

    private static final Set<String> SINGLE_LEVEL = Set.of("mending", "silk_touch", "infinity", "flame",
            "channeling", "multishot", "aqua_affinity", "binding_curse", "vanishing_curse");

    private record Tag(class_1657 player, float x, float y, double dist) { }

    private final List<Tag> tags = new ArrayList<>();

    public Nametags() {
        super("Nametags", Category.RENDER);
    }

    /** Czy mixin ma schowac vanillowe nametagi graczy. */
    public boolean hidesVanilla() { return isEnabled() && hideVanilla.get(); }

    @Override
    protected void onDisable() { tags.clear(); }

    /** Faza swiata: rzutujemy pozycje glow graczy na ekran. */
    @Override
    public void onWorldRender(WorldRenderContext ctx, class_310 mc) {
        tags.clear();
        // Macierz widoku budujemy sami z obrotu kamery (tak jak robi to vanilla),
        // zamiast polegac na ctx.matrixStack(), ktory w 1.21.4 nie zawsze zawiera obrot kamery.
        class_4184 camera = ctx.camera();
        Matrix4f view = new Matrix4f().rotation(camera.method_23767().conjugate(new Quaternionf()));
        Matrix4f mvp = new Matrix4f(ctx.projectionMatrix()).mul(view);
        class_243 cam = camera.method_19326();
        float td = ctx.tickCounter().method_60637(false);
        int sw = mc.method_22683().method_4486();
        int sh = mc.method_22683().method_4502();

        for (class_1657 e : mc.field_1687.method_18456()) {
            if (e == mc.field_1724 || !e.method_5805()) continue;
            double dist = mc.field_1724.method_5739(e);
            if (dist > range.get()) continue;

            class_243 rel = e.method_30950(td).method_1031(0, e.method_17682() + 0.3, 0).method_1020(cam);
            Vector4f v = new Vector4f((float) rel.field_1352, (float) rel.field_1351, (float) rel.field_1350, 1f);
            mvp.transform(v);
            if (v.w <= 0.01f) continue; // za plecami
            float nx = v.x / v.w, ny = v.y / v.w;
            if (nx < -1.5f || nx > 1.5f || ny < -1.5f || ny > 1.5f) continue;

            tags.add(new Tag(e, (nx * 0.5f + 0.5f) * sw, (0.5f - ny * 0.5f) * sh, dist));
        }
    }

    /** Faza HUD: rysujemy tagi (od najdalszych, blizsze na wierzchu). */
    @Override
    public void onHudRender(class_332 ctx, class_310 mc) {
        if (tags.isEmpty()) return;
        List<Tag> sorted = new ArrayList<>(tags);
        tags.clear();
        sorted.sort((a, b) -> Double.compare(b.dist(), a.dist()));
        for (Tag t : sorted) draw(ctx, mc, t);
    }

    private void draw(class_332 ctx, class_310 mc, Tag t) {
        class_327 tr = mc.field_1772;
        class_1657 p = t.player();
        class_4587 ms = ctx.method_51448();

        ms.method_22903();
        ms.method_46416(t.x(), t.y(), 0);
        float s = (float) scale.get();
        ms.method_22905(s, s, 1f);

        int y = 0;

        // linia: nick + ping + hp
        class_2561 header = buildHeader(mc, p);
        if (header != null) {
            int w = tr.method_27525(header);
            ctx.method_25294(-w / 2 - 2, y - 11, w / 2 + 2, y, 0x90000000);
            ctx.method_27535(tr, header, -w / 2, y - 9, 0xFFFFFFFF);
            y -= 12;
        }

        // rzad przedmiotow (+ enchanty nad kazdym)
        List<class_1799> stacks = collectStacks(p);
        int n = stacks.size();
        for (int i = 0; i < n; i++) {
            class_1799 st = stacks.get(i);
            int ix = -n * 9 + i * 18;
            ctx.method_51427(st, ix + 1, y - 17);
            ctx.method_51431(tr, st, ix + 1, y - 17);

            if (!enchants.get()) continue;
            List<class_2561> lines = enchantLines(st);
            for (int k = 0; k < lines.size(); k++) {
                class_2561 line = lines.get(k);
                int lw = tr.method_27525(line);
                ms.method_22903();
                ms.method_46416(ix + 9, y - 17 - 5 * (k + 1), 0);
                ms.method_22905(0.5f, 0.5f, 1f);
                ctx.method_27535(tr, line, -lw / 2, 0, 0xFFFFFFFF);
                ms.method_22909();
            }
        }

        ms.method_22909();
    }

    private class_2561 buildHeader(class_310 mc, class_1657 p) {
        class_5250 out = class_2561.method_43473();
        boolean any = false;

        if (nick.get()) {
            out.method_10852(class_2561.method_43470(p.method_5477().getString()).method_27692(class_124.field_1068));
            any = true;
        }
        if (ping.get() && mc.method_1562() != null) {
            class_640 entry = mc.method_1562().method_2871(p.method_5667());
            if (entry != null) {
                int ms = entry.method_2959();
                class_124 c = ms < 100 ? class_124.field_1060 : ms < 200 ? class_124.field_1054 : class_124.field_1061;
                if (any) out.method_27693(" ");
                out.method_10852(class_2561.method_43470(ms + "ms").method_27692(c));
                any = true;
            }
        }
        if (health.get()) {
            float hp = p.method_6032() + p.method_6067();
            float ratio = p.method_6032() / Math.max(1f, p.method_6063());
            class_124 c = ratio > 0.66f ? class_124.field_1060 : ratio > 0.33f ? class_124.field_1054 : class_124.field_1061;
            if (any) out.method_27693(" ");
            out.method_10852(class_2561.method_43470(String.valueOf(Math.round(hp))).method_27692(c));
            any = true;
        }
        return any ? out : null;
    }

    private List<class_1799> collectStacks(class_1657 p) {
        List<class_1799> list = new ArrayList<>();
        if (mainHand.get()) addIfPresent(list, p.method_6047());
        if (armor.get()) {
            addIfPresent(list, p.method_6118(class_1304.field_6169));
            addIfPresent(list, p.method_6118(class_1304.field_6174));
            addIfPresent(list, p.method_6118(class_1304.field_6172));
            addIfPresent(list, p.method_6118(class_1304.field_6166));
        }
        if (offHand.get()) addIfPresent(list, p.method_6079());
        return list;
    }

    private static void addIfPresent(List<class_1799> list, class_1799 st) {
        if (!st.method_7960()) list.add(st);
    }

    private static List<class_2561> enchantLines(class_1799 st) {
        List<class_2561> out = new ArrayList<>();
        class_9304 comp = st.method_57825(class_9334.field_49633, class_9304.field_49385);
        if (comp.method_57543()) return out;
        for (Object2IntMap.Entry<class_6880<class_1887>> en : comp.method_57539()) {
            String id = en.getKey().method_40230().map(k -> k.method_29177().method_12832()).orElse("?");
            int lvl = en.getIntValue();
            String label = abbr(id) + (lvl == 1 && SINGLE_LEVEL.contains(id) ? "" : " " + lvl);
            out.add(class_2561.method_43470(label).method_27692(id.endsWith("_curse") ? class_124.field_1061 : class_124.field_1075));
            if (out.size() >= 6) break;
        }
        return out;
    }

    private static String abbr(String id) {
        return switch (id) {
            case "protection" -> "Prot";
            case "fire_protection" -> "FireP";
            case "blast_protection" -> "Blast";
            case "projectile_protection" -> "Proj";
            case "feather_falling" -> "Feather";
            case "thorns" -> "Thorns";
            case "respiration" -> "Resp";
            case "aqua_affinity" -> "Aqua";
            case "depth_strider" -> "Depth";
            case "frost_walker" -> "Frost";
            case "soul_speed" -> "Soul";
            case "swift_sneak" -> "Sneak";
            case "unbreaking" -> "Unb";
            case "mending" -> "Mend";
            case "sharpness" -> "Sharp";
            case "smite" -> "Smite";
            case "bane_of_arthropods" -> "Bane";
            case "knockback" -> "KB";
            case "fire_aspect" -> "FireA";
            case "looting" -> "Loot";
            case "sweeping_edge" -> "Sweep";
            case "efficiency" -> "Eff";
            case "silk_touch" -> "Silk";
            case "fortune" -> "Fort";
            case "power" -> "Power";
            case "punch" -> "Punch";
            case "flame" -> "Flame";
            case "infinity" -> "Inf";
            case "binding_curse" -> "Bind";
            case "vanishing_curse" -> "Van";
            default -> {
                String c = Character.toUpperCase(id.charAt(0)) + id.substring(1);
                yield c.length() > 6 ? c.substring(0, 6) : c;
            }
        };
    }
}
