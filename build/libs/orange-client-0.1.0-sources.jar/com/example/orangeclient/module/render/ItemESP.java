package com.example.orangeclient.module.render;

import com.example.orangeclient.module.Category;
import com.example.orangeclient.module.Module;
import com.example.orangeclient.setting.ColorSetting;
import com.example.orangeclient.setting.NumberSetting;
import com.example.orangeclient.util.RenderUtil;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import org.joml.Matrix4f;

/** Obrysy (przez sciany) wokol przedmiotow lezacych na ziemi. */
public class ItemESP extends Module {
    private final NumberSetting range = add(new NumberSetting("Range", 64, 8, 128, 4));
    private final ColorSetting color = add(new ColorSetting("Color", 0xFFFF55, true));

    public ItemESP() {
        super("ItemESP", Category.RENDER);
    }

    @Override
    public void onWorldRender(WorldRenderContext ctx, class_310 mc) {
        class_4587 ms = ctx.matrixStack();
        if (ms == null) return;
        Matrix4f m = ms.method_23760().method_23761();
        class_243 cam = ctx.camera().method_19326();
        float td = ctx.tickCounter().method_60637(false);

        class_287 b = RenderUtil.begin();
        for (class_1297 e : mc.field_1687.method_18112()) {
            if (!(e instanceof class_1542) || !e.method_5805()) continue;
            if (mc.field_1724.method_5739(e) > range.get()) continue;

            class_243 lerped = e.method_30950(td);
            class_238 box = e.method_5829().method_997(lerped.method_1020(e.method_19538()));
            RenderUtil.box(b, m, cam, box, color.argb());
        }
        RenderUtil.end(b);
    }
}
