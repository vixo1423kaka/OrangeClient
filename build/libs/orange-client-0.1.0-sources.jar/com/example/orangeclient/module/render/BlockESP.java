package com.example.orangeclient.module.render;

import com.example.orangeclient.module.Category;
import com.example.orangeclient.module.Module;
import com.example.orangeclient.gui.BlockPickerScreen;
import com.example.orangeclient.setting.ActionSetting;
import com.example.orangeclient.setting.BlockListSetting;
import com.example.orangeclient.setting.BoolSetting;
import com.example.orangeclient.setting.ColorSetting;
import com.example.orangeclient.setting.NumberSetting;
import com.example.orangeclient.util.RenderUtil;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2611;
import net.minecraft.class_2614;
import net.minecraft.class_2627;
import net.minecraft.class_2636;
import net.minecraft.class_2818;
import net.minecraft.class_287;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3719;
import net.minecraft.class_4587;
import net.minecraft.class_7923;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Obrysy (przez sciany) wokol wybranych blokow.
 *  - kategorie (skrzynie, enderchesty, shulkery, beczki, spawnery, leje) czytamy z listy block entity w chunkach - to tanie;
 *  - przycisk "Add Blocks" otwiera okno z lista wszystkich blokow (BlockPickerScreen), w ktorym dodajesz i usuwasz
 *    bloki - te sa skanowane co sekunde w promieniu max. 32 blokow.
 */
public class BlockESP extends Module {
    private static final int SCAN_CAP = 32;
    private static final int MAX_CUSTOM_RESULTS = 2000;

    private final NumberSetting range = add(new NumberSetting("Range", 32, 8, 64, 8));
    private final BoolSetting chests = add(new BoolSetting("Chests", true));
    private final BoolSetting enderChests = add(new BoolSetting("EnderChests", true));
    private final BoolSetting shulkers = add(new BoolSetting("Shulkers", true));
    private final BoolSetting barrels = add(new BoolSetting("Barrels", false));
    private final BoolSetting spawners = add(new BoolSetting("Spawners", true));
    private final BoolSetting hoppers = add(new BoolSetting("Hoppers", false));
    /** Wybrane bloki (ukryte w menu; edytowane przez okno z przycisku "Add Blocks"). Nazwa "Custom" zostaje dla zgodnosci ze starym configiem. */
    private final BlockListSetting blocks = add(new BlockListSetting("Custom"));
    private final ActionSetting addBlocks = add(new ActionSetting("Add Blocks", () -> {
        class_310 mc = class_310.method_1551();
        mc.method_1507(new BlockPickerScreen(mc.field_1755, blocks));
    }));
    private final ColorSetting color = add(new ColorSetting("Color", 0xFF7A00, true));
    private final ColorSetting customColor = add(new ColorSetting("Custom Color", 0x55FFFF, true));

    private int parsedVersion = -1;
    private final Set<class_2248> customBlocks = new HashSet<>();
    private final List<class_2338> customHits = new ArrayList<>();
    private int scanTimer = 0;

    public BlockESP() {
        super("BlockESP", Category.RENDER);
    }

    @Override
    protected void onDisable() {
        customHits.clear();
        scanTimer = 0;
    }

    @Override
    public void onTick(class_310 mc) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        parseCustom();
        if (customBlocks.isEmpty()) {
            customHits.clear();
            return;
        }
        if (scanTimer-- > 0) return;
        scanTimer = 20;
        scan(mc);
    }

    private void parseCustom() {
        if (blocks.version() == parsedVersion) return;
        parsedVersion = blocks.version();
        customBlocks.clear();
        for (String id : blocks.ids()) {
            class_2960 ident = class_2960.method_12829(id);
            if (ident != null && class_7923.field_41175.method_10250(ident)) customBlocks.add(class_7923.field_41175.method_63535(ident));
        }
        scanTimer = 0;
    }

    private void scan(class_310 mc) {
        customHits.clear();
        int r = Math.min((int) range.get(), SCAN_CAP);
        class_2338 p = mc.field_1724.method_24515();
        int minY = Math.max(mc.field_1687.method_31607(), p.method_10264() - r);
        int maxY = Math.min(mc.field_1687.method_31607() + mc.field_1687.method_31605() - 1, p.method_10264() + r);
        class_2338.class_2339 pos = new class_2338.class_2339();
        for (int x = p.method_10263() - r; x <= p.method_10263() + r; x++) {
            for (int z = p.method_10260() - r; z <= p.method_10260() + r; z++) {
                for (int y = minY; y <= maxY; y++) {
                    pos.method_10103(x, y, z);
                    if (customBlocks.contains(mc.field_1687.method_8320(pos).method_26204())) {
                        customHits.add(pos.method_10062());
                        if (customHits.size() >= MAX_CUSTOM_RESULTS) return;
                    }
                }
            }
        }
    }

    private boolean wanted(class_2586 be) {
        if (be instanceof class_2595) return chests.get();          // obejmuje tez trapped chest
        if (be instanceof class_2611) return enderChests.get();
        if (be instanceof class_2627) return shulkers.get();
        if (be instanceof class_3719) return barrels.get();
        if (be instanceof class_2636) return spawners.get();
        if (be instanceof class_2614) return hoppers.get();
        return false;
    }

    @Override
    public void onWorldRender(WorldRenderContext ctx, class_310 mc) {
        class_4587 ms = ctx.matrixStack();
        if (ms == null) return;
        Matrix4f m = ms.method_23760().method_23761();
        class_243 cam = ctx.camera().method_19326();
        double maxDistSq = range.get() * range.get();
        class_243 eye = mc.field_1724.method_33571();

        class_287 b = RenderUtil.begin();

        // block entity z chunkow w poblizu
        int chunkR = ((int) range.get() >> 4) + 1;
        int pcx = mc.field_1724.method_24515().method_10263() >> 4;
        int pcz = mc.field_1724.method_24515().method_10260() >> 4;
        for (int cx = pcx - chunkR; cx <= pcx + chunkR; cx++) {
            for (int cz = pcz - chunkR; cz <= pcz + chunkR; cz++) {
                class_2818 chunk = mc.field_1687.method_8497(cx, cz);
                for (class_2586 be : chunk.method_12214().values()) {
                    if (!wanted(be)) continue;
                    class_2338 bp = be.method_11016();
                    if (eye.method_1028(bp.method_10263() + 0.5, bp.method_10264() + 0.5, bp.method_10260() + 0.5) > maxDistSq) continue;
                    RenderUtil.box(b, m, cam, new class_238(bp), color.argb());
                }
            }
        }

        // bloki z pola Custom (wynik skanu sprzed max. sekundy)
        for (class_2338 bp : customHits) {
            RenderUtil.box(b, m, cam, new class_238(bp), customColor.argb());
        }

        RenderUtil.end(b);
    }
}
