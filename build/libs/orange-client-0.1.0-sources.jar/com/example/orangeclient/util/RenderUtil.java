package com.example.orangeclient.util;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_10142;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_9801;
import org.joml.Matrix4f;

public final class RenderUtil {
    private RenderUtil() { }

    public static class_287 begin() {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.setShader(class_10142.field_53876);
        RenderSystem.lineWidth(2.0f);
        return class_289.method_1348().method_60827(class_293.class_5596.field_29344, class_290.field_1576);
    }

    public static void end(class_287 b) {
        class_9801 built = b.method_60794();
        if (built != null) class_286.method_43433(built);
        RenderSystem.lineWidth(1.0f);
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    /** Linia w ukladzie wspolrzednych wzglednych do kamery. */
    public static void lineRel(class_287 b, Matrix4f m, class_243 a, class_243 c, int argb) {
        b.method_22918(m, (float) a.field_1352, (float) a.field_1351, (float) a.field_1350).method_39415(argb);
        b.method_22918(m, (float) c.field_1352, (float) c.field_1351, (float) c.field_1350).method_39415(argb);
    }

    /** Linia w swiecie, przeliczana na uklad kamery. */
    public static void line(class_287 b, Matrix4f m, class_243 cam, class_243 a, class_243 c, int argb) {
        lineRel(b, m, a.method_1020(cam), c.method_1020(cam), argb);
    }

    public static void box(class_287 b, Matrix4f m, class_243 cam, class_238 bx, int argb) {
        class_243[] p = {
                new class_243(bx.field_1323, bx.field_1322, bx.field_1321), new class_243(bx.field_1320, bx.field_1322, bx.field_1321),
                new class_243(bx.field_1320, bx.field_1322, bx.field_1324), new class_243(bx.field_1323, bx.field_1322, bx.field_1324),
                new class_243(bx.field_1323, bx.field_1325, bx.field_1321), new class_243(bx.field_1320, bx.field_1325, bx.field_1321),
                new class_243(bx.field_1320, bx.field_1325, bx.field_1324), new class_243(bx.field_1323, bx.field_1325, bx.field_1324)
        };
        int[][] edges = {
                {0, 1}, {1, 2}, {2, 3}, {3, 0},
                {4, 5}, {5, 6}, {6, 7}, {7, 4},
                {0, 4}, {1, 5}, {2, 6}, {3, 7}
        };
        for (int[] e : edges) line(b, m, cam, p[e[0]], p[e[1]], argb);
    }

    // ---------- wypelnione (polprzezroczyste) boxy ----------
    public static class_287 beginFill() {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.setShader(class_10142.field_53876);
        return class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
    }

    public static void endFill(class_287 b) {
        class_9801 built = b.method_60794();
        if (built != null) class_286.method_43433(built);
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    /** Wypelnia wszystkie 6 scian boxa kolorem ARGB (alpha = przezroczystosc). */
    public static void fillBox(class_287 b, Matrix4f m, class_243 cam, class_238 bx, int argb) {
        float x1 = (float) (bx.field_1323 - cam.field_1352), y1 = (float) (bx.field_1322 - cam.field_1351), z1 = (float) (bx.field_1321 - cam.field_1350);
        float x2 = (float) (bx.field_1320 - cam.field_1352), y2 = (float) (bx.field_1325 - cam.field_1351), z2 = (float) (bx.field_1324 - cam.field_1350);
        quad(b, m, argb, x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2);   // dol
        quad(b, m, argb, x1, y2, z1, x1, y2, z2, x2, y2, z2, x2, y2, z1);   // gora
        quad(b, m, argb, x1, y1, z1, x1, y2, z1, x2, y2, z1, x2, y1, z1);   // polnoc
        quad(b, m, argb, x1, y1, z2, x2, y1, z2, x2, y2, z2, x1, y2, z2);   // poludnie
        quad(b, m, argb, x1, y1, z1, x1, y1, z2, x1, y2, z2, x1, y2, z1);   // zachod
        quad(b, m, argb, x2, y1, z1, x2, y2, z1, x2, y2, z2, x2, y1, z2);   // wschod
    }

    private static void quad(class_287 b, Matrix4f m, int argb,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz) {
        b.method_22918(m, ax, ay, az).method_39415(argb);
        b.method_22918(m, bx, by, bz).method_39415(argb);
        b.method_22918(m, cx, cy, cz).method_39415(argb);
        b.method_22918(m, dx, dy, dz).method_39415(argb);
    }
}
