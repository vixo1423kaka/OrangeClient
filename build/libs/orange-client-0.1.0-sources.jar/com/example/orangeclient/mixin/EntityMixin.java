package com.example.orangeclient.mixin;

import com.example.orangeclient.module.ModuleManager;
import com.example.orangeclient.module.movement.Freecam;
import com.example.orangeclient.module.player.NoPush;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3611;
import net.minecraft.class_6862;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1297.class)
public abstract class EntityMixin {
    @Unique private class_243 orange$pushVelocity;
    @Unique private class_243 orange$fluidVelocity;

    /** Freecam: ruch myszy obraca kamere, a nie gracza. */
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true, require = 0)
    private void orange$freecamLook(double cursorDeltaX, double cursorDeltaY, CallbackInfo ci) {
        if ((Object) this instanceof class_746 && Freecam.isActive()) {
            Freecam.look(cursorDeltaX, cursorDeltaY);
            ci.cancel();
        }
    }

    /**
     * pushAwayFrom zmienia predkosc OBU encji naraz, wiec nie anulujemy metody
     * (inni gracze dalej sie odpychaja), tylko zapamietujemy predkosc lokalnego gracza
     * przed i przywracamy ja po wywolaniu.
     */
    @Inject(method = "pushAwayFrom", at = @At("HEAD"))
    private void orange$pushHead(class_1297 other, CallbackInfo ci) {
        orange$pushVelocity = null;
        class_746 p = class_310.method_1551().field_1724;
        NoPush np = ModuleManager.get(NoPush.class);
        if (p == null || np == null || !np.blocksEntityPush()) return;
        if ((Object) this == p || other == p) orange$pushVelocity = p.method_18798();
    }

    @Inject(method = "pushAwayFrom", at = @At("RETURN"))
    private void orange$pushReturn(class_1297 other, CallbackInfo ci) {
        if (orange$pushVelocity == null) return;
        class_746 p = class_310.method_1551().field_1724;
        if (p != null) p.method_18799(orange$pushVelocity);
        orange$pushVelocity = null;
    }

    /** updateMovementInFluid zmienia predkosc tylko przez nurt wody/lawy - cofamy to. */
    @Inject(method = "updateMovementInFluid", at = @At("HEAD"))
    private void orange$fluidHead(class_6862<class_3611> tag, double speed, CallbackInfoReturnable<Boolean> cir) {
        orange$fluidVelocity = null;
        NoPush np = ModuleManager.get(NoPush.class);
        if (np != null && np.blocksLiquidPush() && (Object) this instanceof class_746) {
            orange$fluidVelocity = ((class_1297) (Object) this).method_18798();
        }
    }

    @Inject(method = "updateMovementInFluid", at = @At("RETURN"))
    private void orange$fluidReturn(class_6862<class_3611> tag, double speed, CallbackInfoReturnable<Boolean> cir) {
        if (orange$fluidVelocity == null) return;
        ((class_1297) (Object) this).method_18799(orange$fluidVelocity);
        orange$fluidVelocity = null;
    }
}
