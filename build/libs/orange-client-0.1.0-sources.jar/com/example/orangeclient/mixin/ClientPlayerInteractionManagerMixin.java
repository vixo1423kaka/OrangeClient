package com.example.orangeclient.mixin;

import com.example.orangeclient.module.combat.KnockbackDisplacement;
import com.example.orangeclient.module.player.AntiTrap;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_636.class)
public abstract class ClientPlayerInteractionManagerMixin {

    @Unique
    private boolean orange$kbRotated = false;
    /** Tick gracza (age), w ktorym ostatnio wyslalismy przesuniety yaw. */
    @Unique
    private int orange$kbLastTick = Integer.MIN_VALUE / 2;

    /**
     * Kolejnosc pakietow: look(yaw + offset) -> interact(attack) -> look(prawdziwy yaw).
     * Pakiet ataku wysyla oryginalna attackEntity, wiec jej nie anulujemy.
     */
    @Inject(method = "attackEntity", at = @At("HEAD"))
    private void orange$kbBefore(class_1657 player, class_1297 target, CallbackInfo ci) {
        orange$kbRotated = false;

        KnockbackDisplacement m = KnockbackDisplacement.active();
        if (m == null) return;
        if (!(player instanceof class_746 self)) return;
        if (target == null || !target.method_5805() || target.method_31481()) return;
        int offset = m.getOffset();
        if (offset == 0) return;
        // limit pakietow: max 1 przesuniecie na MinInterval tickow (min. 1 na tick)
        if (self.field_6012 - orange$kbLastTick < Math.max(1, m.getMinInterval())) return;
        // nie ruszamy rotacji, gdy serwer czeka na teleport / gracz jest w pojezdzie / spectator
        if (self.method_5765() || self.method_7325() || self.method_29504()) return;
        if (orange$eyeDistanceToBox(self, target) > m.getRange()) return;

        orange$kbLastTick = self.field_6012;
        orange$sendLook(self, self.method_36454() + offset, self.method_36455());
        orange$kbRotated = true;
    }

    @Inject(method = "attackEntity", at = @At("RETURN"))
    private void orange$kbAfter(class_1657 player, class_1297 target, CallbackInfo ci) {
        if (!orange$kbRotated) return;
        orange$kbRotated = false;
        if (player instanceof class_746 self) {
            orange$sendLook(self, self.method_36454(), self.method_36455());
        }
    }

    /** AntiTrap: PPM na blok z GUI (skrzynka, tabliczka...) nie wysyla interakcji, wiec nic sie nie otwiera. */
    @Inject(method = "interactBlock", at = @At("HEAD"), cancellable = true)
    private void orange$antiTrapNoGui(class_746 player, class_1268 hand, class_3965 hitResult,
                                      CallbackInfoReturnable<class_1269> cir) {
        if (AntiTrap.blocksGui(player, hitResult)) cir.setReturnValue(class_1269.field_5814);
    }

    @Unique
    private static void orange$sendLook(class_746 self, float yaw, float pitch) {
        if (self.field_3944 == null) return;
        // od 1.21.2 konstruktor ma 4 parametry: yaw, pitch, onGround, horizontalCollision
        self.field_3944.method_52787(new class_2828.class_2831(
                class_3532.method_15393(yaw), class_3532.method_15363(pitch, -90f, 90f),
                self.method_24828(), self.field_5976));
    }

    @Unique
    private static double orange$eyeDistanceToBox(class_746 self, class_1297 target) {
        class_238 b = target.method_5829();
        class_243 eye = self.method_33571();
        double dx = Math.max(Math.max(b.field_1323 - eye.field_1352, 0), eye.field_1352 - b.field_1320);
        double dy = Math.max(Math.max(b.field_1322 - eye.field_1351, 0), eye.field_1351 - b.field_1325);
        double dz = Math.max(Math.max(b.field_1321 - eye.field_1350, 0), eye.field_1350 - b.field_1324);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }
}
