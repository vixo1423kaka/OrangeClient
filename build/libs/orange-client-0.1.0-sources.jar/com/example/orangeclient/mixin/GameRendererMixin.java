package com.example.orangeclient.mixin;

import com.example.orangeclient.module.combat.Hitbox;
import com.example.orangeclient.module.player.AntiTrap;
import com.example.orangeclient.module.render.Removals;
import net.minecraft.class_1297;
import net.minecraft.class_239;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_757.class)
public abstract class GameRendererMixin {
    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true, require = 0)
    private void orange$noHurtCam(CallbackInfo ci) {
        if (Removals.noHurtCam()) ci.cancel();
    }

    @Inject(method = "showFloatingItem", at = @At("HEAD"), cancellable = true, require = 0)
    private void orange$noTotem(CallbackInfo ci) {
        if (Removals.noTotem()) ci.cancel();
    }

    /**
     * AntiTrap: jesli vanilla trafilo w encje, liczymy celownik jeszcze raz
     * tylko dla blokow - encje przestaja zaslaniac to, co jest za nimi.
     */
    @Inject(method = "findCrosshairTarget", at = @At("RETURN"), cancellable = true)
    private void orange$antiTrap(class_1297 camera, double blockRange, double entityRange, float tickDelta,
                                            CallbackInfoReturnable<class_239> cir) {
        // Hitbox najpierw (w tym samym wstrzyknieciu, zeby kolejnosc byla przewidywalna)
        class_239 original = cir.getReturnValue();
        class_239 hr = Hitbox.adjust(original, camera, blockRange, entityRange, tickDelta);
        if (hr != original) cir.setReturnValue(hr);

        if (hr != null && hr.method_17783() == class_239.class_240.field_1331
                && (AntiTrap.active() || AntiTrap.hides(((class_3966) hr).method_17782()))) {
            cir.setReturnValue(camera.method_5745(blockRange, tickDelta, false));
        }

        // AntiTrap: kopiemy plotek/cobweb pod graczem "przez" cobweb - celownik idzie wprost na pulapke,
        // zamiast na cobweb, w ktory vanilla by trafilo (dzieki temu cobweb zostaje nietkniety).
        // Musi byc na samym koncu, bo vanilla przelicza celownik po naszym onPreTick.
        class_3965 forced = AntiTrap.forcedHit();
        if (forced != null) cir.setReturnValue(forced);
    }
}
