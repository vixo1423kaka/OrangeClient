package com.example.orangeclient.mixin;

import com.example.orangeclient.module.render.Removals;
import net.minecraft.class_2960;
import net.minecraft.class_329;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public abstract class InGameHudMixin {
    /** Nakladki tekstur na ekranie: dynia i powder snow. */
    @Inject(method = "renderOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void orange$overlay(class_332 context, class_2960 texture, float opacity, CallbackInfo ci) {
        String path = texture.method_12832();
        if (path.contains("pumpkinblur") && Removals.noPumpkin()) ci.cancel();
        else if (path.contains("powder_snow") && Removals.noPowderSnow()) ci.cancel();
    }

    @Inject(method = "renderPortalOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void orange$portal(CallbackInfo ci) {
        if (Removals.noPortal()) ci.cancel();
    }

    @Inject(method = "renderVignetteOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void orange$vignette(CallbackInfo ci) {
        if (Removals.noVignette()) ci.cancel();
    }
}
