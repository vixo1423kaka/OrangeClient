package com.example.orangeclient.mixin;

import com.example.orangeclient.module.ModuleManager;
import com.example.orangeclient.module.movement.FakeLag;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_7648;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2535.class)
public abstract class ClientConnectionMixin {
    /** FakeLag: przejmuje pakiety wychodzace (kazda sciezka send() konczy sie w tej metodzie). */
    @Inject(
            method = "send(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/PacketCallbacks;Z)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void orange$fakeLag(class_2596<?> packet, class_7648 callbacks, boolean flush, CallbackInfo ci) {
        FakeLag fl = ModuleManager.get(FakeLag.class);
        if (fl != null && fl.isEnabled() && fl.intercept((class_2535) (Object) this, packet, callbacks)) ci.cancel();
    }
}
