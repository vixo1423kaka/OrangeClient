package com.example.orangeclient.mixin;

import com.example.orangeclient.module.ModuleManager;
import com.example.orangeclient.module.combat.KillAura;
import com.example.orangeclient.module.render.Nametags;
import net.minecraft.class_10042;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_922.class)
public abstract class LivingEntityRendererMixin {
    /** Chowa vanillowy nametag graczy, gdy wlaczony jest modul Nametags (opcja HideVanilla). */
    @Inject(method = "hasLabel", at = @At("HEAD"), cancellable = true)
    private void orange$hideVanillaLabel(class_1309 entity, double squaredDistance, CallbackInfoReturnable<Boolean> cir) {
        if (!(entity instanceof class_1657)) return;
        Nametags nt = ModuleManager.get(Nametags.class);
        if (nt != null && nt.hidesVanilla()) cir.setReturnValue(false);
    }

    /**
     * KillAura (Silent): kamera zostaje na miejscu, ale model WLASNEGO gracza (3. osoba) jest rysowany
     * z rotacja wysylana do serwera (opcja SilentModel).
     */
    @Inject(method = "updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V",
            at = @At("RETURN"), require = 0)
    private void orange$silentRotationModel(class_1309 entity, class_10042 state, float tickDelta, CallbackInfo ci) {
        if (entity != class_310.method_1551().field_1724) return;
        KillAura ka = ModuleManager.get(KillAura.class);
        if (ka == null || !ka.isRenderRotating()) return;
        state.field_53446 = ka.renderYaw(tickDelta);
        state.field_53447 = 0f;
        state.field_53448 = ka.renderPitch(tickDelta);
    }
}
