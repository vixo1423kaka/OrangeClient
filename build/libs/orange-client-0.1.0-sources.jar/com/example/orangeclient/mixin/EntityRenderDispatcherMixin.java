package com.example.orangeclient.mixin;

import com.example.orangeclient.module.player.AntiTrap;
import net.minecraft.class_1297;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4604;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_898.class)
public abstract class EntityRenderDispatcherMixin {
    /** AntiTrap: obrazy, item framey i minecarty nie sa w ogole kwalifikowane do renderowania. */
    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private void orange$antiTrapShouldRender(class_1297 entity, class_4604 frustum, double x, double y, double z,
                                             CallbackInfoReturnable<Boolean> cir) {
        if (AntiTrap.hides(entity)) cir.setReturnValue(false);
    }

    /** Zabezpieczenie: encja, ktora renderuje sie mimo shouldRender (np. minecart, w ktorym jedziesz). */
    @Inject(method = "render(Lnet/minecraft/entity/Entity;DDDFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void orange$antiTrapRender(class_1297 entity, double x, double y, double z, float tickDelta,
                                       class_4587 matrices, class_4597 vertexConsumers, int light,
                                       CallbackInfo ci) {
        if (AntiTrap.hides(entity)) ci.cancel();
    }
}
