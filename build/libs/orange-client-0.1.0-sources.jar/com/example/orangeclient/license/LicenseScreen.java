package com.example.orangeclient.license;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_442;

public class LicenseScreen extends class_437 {
    private final class_437 parent;
    private class_342 keyField;
    private class_4185 activateButton;
    private String status = "";
    private int statusColor = 0xFFAAAAAA;

    public LicenseScreen(class_437 parent) {
        super(class_2561.method_43470("Licencja"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx = field_22789 / 2;
        int cy = field_22790 / 2;

        keyField = new class_342(field_22793, cx - 100, cy - 10, 200, 20, class_2561.method_43470("Klucz"));
        keyField.method_1880(64);
        keyField.method_47404(class_2561.method_43470("Wpisz klucz licencyjny..."));
        method_37063(keyField);
        method_48265(keyField);

        activateButton = class_4185.method_46430(class_2561.method_43470("Aktywuj"), b -> activate())
                .method_46434(cx - 100, cy + 18, 98, 20).method_46431();
        method_37063(activateButton);

        method_37063(class_4185.method_46430(class_2561.method_43470("Wyjdz z gry"), b -> class_310.method_1551().method_1592())
                .method_46434(cx + 2, cy + 18, 98, 20).method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43470("Rozlacz"), b -> {
            class_310 mc = class_310.method_1551();
            if (mc.field_1687 != null) mc.field_1687.method_8525();
            mc.method_56134(new class_442());
        }).method_46434(cx - 100, cy + 42, 200, 20).method_46431());
    }

    private void activate() {
        String key = keyField.method_1882().trim();
        if (key.isEmpty()) {
            setStatus("Wpisz klucz!", 0xFFFF5555);
            return;
        }
        activateButton.field_22763 = false;
        setStatus("Sprawdzanie...", 0xFFFFFF55);
        LicenseManager.validate(key).thenAccept(err -> class_310.method_1551().execute(() -> {
            activateButton.field_22763 = true;
            if (err == null) {
                class_310.method_1551().method_1507(parent);
            } else {
                setStatus(err, 0xFFFF5555);
            }
        }));
    }

    private void setStatus(String s, int color) { status = s; statusColor = color; }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 257 || keyCode == 335) { // ENTER / NUM ENTER
            if (activateButton.field_22763) activate();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        super.method_25394(ctx, mouseX, mouseY, delta);
        int cx = field_22789 / 2;
        int cy = field_22790 / 2;
        ctx.method_27534(field_22793, class_2561.method_43470("Orange Client - wymagana licencja"), cx, cy - 50, 0xFFFF9A2E);
        ctx.method_27534(field_22793, class_2561.method_43470("Wpisz klucz, aby uzywac clienta"), cx, cy - 34, 0xFFAAAAAA);
        if (!status.isEmpty()) ctx.method_27534(field_22793, class_2561.method_43470(status), cx, cy + 70, statusColor);
    }

    /** Okna nie da sie zamknac ESC-em. */
    @Override
    public boolean method_25422() { return false; }
}
